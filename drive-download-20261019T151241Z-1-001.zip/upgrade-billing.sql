-- Run once in phpMyAdmin (SQL tab) if you already imported an older database.sql.
-- Older bookings have no price breakdown, so their invoices show one rental line.
USE roadkey;
ALTER TABLE bookings
  ADD COLUMN daily_rate INT NULL AFTER fee,
  ADD COLUMN surcharge INT NOT NULL DEFAULT 0 AFTER daily_rate,
  ADD COLUMN discount INT NOT NULL DEFAULT 0 AFTER surcharge;
CREATE TABLE IF NOT EXISTS booking_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT NOT NULL,
  kind ENUM('charge','payment') NOT NULL,
  description VARCHAR(120) NOT NULL,
  amount INT NOT NULL,
  created_by VARCHAR(50) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
  INDEX (booking_id)
);
