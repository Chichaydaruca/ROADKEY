CREATE DATABASE IF NOT EXISTS roadkey CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE roadkey;
CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL
);
CREATE TABLE IF NOT EXISTS cars (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL,
  plate VARCHAR(12) NULL UNIQUE,
  type VARCHAR(20) NOT NULL,
  seats TINYINT NOT NULL DEFAULT 5,
  mileage INT NOT NULL DEFAULT 0,
  rate INT NOT NULL,
  branch VARCHAR(30) NOT NULL,
  status ENUM('ok','maint','retired') NOT NULL DEFAULT 'ok',
  photo VARCHAR(60) NULL
);
CREATE TABLE IF NOT EXISTS customers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  phone VARCHAR(30) NOT NULL,
  address VARCHAR(200) NULL,
  birth_date DATE NULL,
  license VARCHAR(40) NOT NULL,
  license_expiry DATE NULL,
  emergency_contact VARCHAR(120) NULL,
  notes VARCHAR(500) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX (license)
);
CREATE TABLE IF NOT EXISTS bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ref VARCHAR(12) NOT NULL UNIQUE,
  car_id INT NOT NULL,
  customer_id INT NULL,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(120) NOT NULL,
  phone VARCHAR(30) NOT NULL,
  license VARCHAR(40) NOT NULL,
  license_expiry DATE NULL,
  license_photo VARCHAR(60) NULL,
  selfie_photo VARCHAR(60) NULL,
  verified TINYINT(1) NOT NULL DEFAULT 0,
  verified_by VARCHAR(50) NULL,
  verified_at DATETIME NULL,
  flag VARCHAR(160) NULL,
  date_from DATE NOT NULL,
  date_to DATE NOT NULL,
  total INT NOT NULL,
  deposit INT NOT NULL,
  paid INT NOT NULL,
  refunded INT NOT NULL DEFAULT 0,
  fee INT NOT NULL DEFAULT 0,
  daily_rate INT NULL,
  surcharge INT NOT NULL DEFAULT 0,
  discount INT NOT NULL DEFAULT 0,
  due_now INT NOT NULL DEFAULT 0,
  gateway_ref VARCHAR(80) NULL,
  hold_until DATETIME NULL,
  status ENUM('reserved','picked','returned','cancelled') NOT NULL DEFAULT 'reserved',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (car_id) REFERENCES cars(id),
  FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL,
  INDEX (car_id, date_from, date_to),
  INDEX (email),
  INDEX (license)
);
CREATE TABLE IF NOT EXISTS booking_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT NOT NULL,
  kind ENUM('charge','payment') NOT NULL,
  description VARCHAR(120) NOT NULL,
  amount INT NOT NULL,
  created_by VARCHAR(50) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
  INDEX (booking_id)
);
CREATE TABLE IF NOT EXISTS payments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT NOT NULL,
  kind ENUM('payment','refund') NOT NULL,
  amount INT NOT NULL,
  method VARCHAR(30) NOT NULL,
  status ENUM('completed','pending','void') NOT NULL DEFAULT 'completed',
  reference VARCHAR(80) NULL,
  gateway_id VARCHAR(80) NULL UNIQUE,
  note VARCHAR(120) NOT NULL DEFAULT '',
  created_by VARCHAR(50) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
  INDEX (booking_id)
);
CREATE TABLE IF NOT EXISTS documents (
  id INT AUTO_INCREMENT PRIMARY KEY,
  doc_type VARCHAR(10) NOT NULL,
  seq INT NOT NULL,
  number VARCHAR(40) NOT NULL UNIQUE,
  booking_id INT NOT NULL,
  payment_id INT NOT NULL DEFAULT 0,
  issued_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (doc_type, seq),
  UNIQUE (booking_id, doc_type, payment_id),
  FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS doc_counters (
  doc_type VARCHAR(10) PRIMARY KEY,
  last_seq INT NOT NULL
);
CREATE TABLE IF NOT EXISTS blocked_licenses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  license VARCHAR(40) NOT NULL UNIQUE,
  reason VARCHAR(200) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS maintenance (
  id INT AUTO_INCREMENT PRIMARY KEY,
  car_id INT NOT NULL,
  kind VARCHAR(30) NOT NULL,
  date_from DATE NOT NULL,
  date_to DATE NOT NULL,
  notes VARCHAR(300) NOT NULL DEFAULT '',
  cost INT NOT NULL DEFAULT 0,
  status ENUM('scheduled','done','cancelled') NOT NULL DEFAULT 'scheduled',
  created_by VARCHAR(50) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (car_id) REFERENCES cars(id),
  INDEX (car_id, date_from, date_to)
);
INSERT INTO cars (name,plate,type,seats,mileage,rate,branch) VALUES
('Toyota Vios','NBC 1234','Sedan',5,18200,1800,'Manila'),('Toyota Fortuner','NDA 5678','SUV',7,32100,3800,'Manila'),
('Mitsubishi Xpander','VAB 2468','MPV',7,25400,2800,'Cebu'),('Honda City','CAD 1357','Sedan',5,14900,2000,'Cebu'),
('Toyota Hiace','NEC 9021','Van',12,48800,4500,'Davao'),('Ford Ranger','DAB 4410','Pickup',5,39500,3500,'Davao');
