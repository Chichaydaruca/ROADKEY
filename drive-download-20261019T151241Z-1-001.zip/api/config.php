<?php
// Database settings (XAMPP defaults). Change DB_PASS if you set a MySQL password.
const DB_HOST = '127.0.0.1', DB_NAME = 'roadkey', DB_USER = 'root', DB_PASS = '';
const DEPOSIT = 5000;
const BRANCHES = ['Manila', 'Cebu', 'Davao'];
date_default_timezone_set('Asia/Manila');
session_set_cookie_params(['httponly' => true, 'samesite' => 'Strict']);
session_start();

function db(): PDO {
  static $pdo;
  return $pdo ??= new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
  ]);
}

/** Weekend days +15%, 7+ days -10%. Prices are always calculated here, never trusted from the browser. */
function quote(int $rate, string $from, string $to): array {
  $days = (new DateTime($from))->diff(new DateTime($to))->days;
  $t = new DateTime($from); $sub = 0; $weekend = 0;
  for ($i = 0; $i < $days; $i++) {
    $w = (int)$t->format('w'); $f = ($w === 5 || $w === 6) ? 1.15 : 1;
    if ($f > 1) $weekend++;
    $sub += $rate * $f; $t->modify('+1 day');
  }
  $sub = (int)round($sub); $disc = $days >= 7 ? (int)round($sub * 0.1) : 0;
  return ['days' => $days, 'weekend' => $weekend, 'surcharge' => $sub - $days * $rate, 'discount' => $disc, 'total' => $sub - $disc];
}

const MAX_UPLOAD = 2 * 1024 * 1024;               // matches XAMPP's default upload limit
define('PRIVATE_DIR', dirname(__DIR__, 3) . '/roadkey_private');  // outside htdocs: not reachable by URL

/** Read a value from settings.php, e.g. S('payments.mode'). */
function S(string $path, $default = null) {
  static $all; $all ??= require __DIR__ . '/settings.php';
  $v = $all;
  foreach (explode('.', $path) as $k) { if (!is_array($v) || !array_key_exists($k, $v)) return $default; $v = $v[$k]; }
  return $v;
}
