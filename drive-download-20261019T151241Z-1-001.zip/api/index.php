<?php
require __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');
function out($d, int $c = 200) { http_response_code($c); echo json_encode($d); exit; }
function fail(string $m, int $c = 400) { out(['error' => $m], $c); }
function need_admin() { if (empty($_SESSION['admin'])) fail('Please sign in.', 401); }
function date_ok($d) { return is_string($d) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $d) && checkdate((int)substr($d, 5, 2), (int)substr($d, 8, 2), (int)substr($d, 0, 4)); }
function dates($f, $t) {
  if (!date_ok($f) || !date_ok($t)) fail('Choose valid dates.');
  if ($f < date('Y-m-d')) fail('Pickup cannot be in the past.');
  if ($t <= $f) fail('Return must be after pickup.');
  if ((new DateTime($f))->diff(new DateTime($t))->days > 60) fail('The longest rental is 60 days.');
}
const FREE = "NOT EXISTS (SELECT 1 FROM bookings b WHERE b.car_id=c.id AND b.status IN ('reserved','picked') AND b.date_from < ? AND ? < b.date_to) AND NOT EXISTS (SELECT 1 FROM maintenance m WHERE m.car_id=c.id AND m.status='scheduled' AND m.date_from < ? AND ? <= m.date_to)";

function norm_license(string $l): ?string {   // the same licence typed in different ways gives the same stored value
  $k = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $l));
  if (strlen($k) < 5 || strlen($k) > 20) return null;
  $pat = (string)S('license.pattern', ''); if ($pat !== '' && !preg_match($pat, $k)) return null;
  return preg_match('/^[A-Z][0-9]{9}$/', $k) ? substr($k, 0, 3) . '-' . substr($k, 3, 2) . '-' . substr($k, 5) : $k;
}
function save_photo(string $field, bool $required): ?string {
  $f = $_FILES[$field] ?? null;
  if (!$f || $f['error'] === UPLOAD_ERR_NO_FILE) { if ($required) fail('Please upload a photo of your licence.'); return null; }
  $bad = 'Photos must be JPG or PNG and under 2 MB.';
  if ($f['error'] !== UPLOAD_ERR_OK || $f['size'] > MAX_UPLOAD) fail($bad);
  $ext = ['image/jpeg' => 'jpg', 'image/png' => 'png'][(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name'])] ?? null;
  if (!$ext || !@getimagesize($f['tmp_name'])) fail($bad);
  if (!is_dir(PRIVATE_DIR) && !mkdir(PRIVATE_DIR, 0750, true)) fail('The server cannot store uploads. Check folder permissions.', 500);
  $name = bin2hex(random_bytes(16)) . '.' . $ext;
  if (!move_uploaded_file($f['tmp_name'], PRIVATE_DIR . '/' . $name)) fail('Upload failed. Please try again.', 500);
  return $name;
}
function drop_photos(PDO $pdo, int $id) {   // privacy: images are deleted once the rental is over or cancelled
  $s = $pdo->prepare('SELECT license_photo, selfie_photo FROM bookings WHERE id=?'); $s->execute([$id]);
  foreach ($s->fetch() ?: [] as $n) if ($n) @unlink(PRIVATE_DIR . '/' . basename($n));
  $pdo->prepare('UPDATE bookings SET license_photo=NULL, selfie_photo=NULL WHERE id=?')->execute([$id]);
}

function car_fields(array $in): array {
  $name = trim($in['name'] ?? ''); $type = $in['type'] ?? ''; $rate = (int)($in['rate'] ?? 0); $seats = (int)($in['seats'] ?? 5); $br = $in['branch'] ?? '';
  $plate = strtoupper(preg_replace('/\s+/', ' ', trim($in['plate'] ?? ''))); $km = (int)($in['mileage'] ?? 0);
  if (strlen($name) < 2 || strlen($name) > 80 || !in_array($type, ['Sedan', 'SUV', 'MPV', 'Van', 'Pickup'], true) || $rate < 500 || $rate > 100000 || $seats < 2 || $seats > 20 || !in_array($br, BRANCHES, true)) fail('Check the vehicle details.');
  if (!preg_match('/^[A-Z0-9][A-Z0-9 -]{3,10}[A-Z0-9]$/', $plate)) fail('Enter the plate number, like ABC 1234.');
  if ($km < 0 || $km > 2000000) fail('Check the mileage.');
  return [$name, $type, $seats, $rate, $br, $plate, $km];
}
function save_car_photo(array $f): string {   // public photos: re-encoded with GD so nothing hidden in the file survives
  $bad = 'The photo must be a JPG or PNG under 2 MB.';
  if ($f['error'] !== UPLOAD_ERR_OK || $f['size'] > MAX_UPLOAD) fail($bad);
  $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
  if (!in_array($mime, ['image/jpeg', 'image/png'], true) || !@getimagesize($f['tmp_name'])) fail($bad);
  $dir = dirname(__DIR__) . '/uploads/cars';
  if (!is_dir($dir) && !mkdir($dir, 0755, true)) fail('Cannot create the uploads folder.', 500);
  $name = bin2hex(random_bytes(12)) . '.jpg';
  if (function_exists('imagecreatefromstring')) {
    $im = @imagecreatefromstring(file_get_contents($f['tmp_name'])); if (!$im) fail($bad);
    $w = imagesx($im); $h = imagesy($im); $k = min(1, 1200 / max($w, $h)); $nw = max(1, (int)round($w * $k)); $nh = max(1, (int)round($h * $k));
    $out = imagecreatetruecolor($nw, $nh); imagefill($out, 0, 0, imagecolorallocate($out, 255, 255, 255)); imagecopyresampled($out, $im, 0, 0, 0, 0, $nw, $nh, $w, $h);
    $ok = imagejpeg($out, "$dir/$name", 85);
  } else { $name = bin2hex(random_bytes(12)) . ($mime === 'image/png' ? '.png' : '.jpg'); $ok = move_uploaded_file($f['tmp_name'], "$dir/$name"); }
  if (!$ok) fail('Could not save the photo.', 500);
  return $name;
}
function car_row(PDO $pdo, array $in): array {
  $s = $pdo->prepare('SELECT * FROM cars WHERE id=?'); $s->execute([(int)($in['id'] ?? 0)]);
  return $s->fetch() ?: fail('Vehicle not found.', 404);
}
function car_bookings(PDO $pdo, int $id, string $statuses): int {   // $statuses is always a fixed list from this file
  $s = $pdo->prepare("SELECT COUNT(*) FROM bookings WHERE car_id=? AND status IN ($statuses)"); $s->execute([$id]); return (int)$s->fetchColumn();
}
const ACTIVE = "'reserved','picked'";

function cust_fields(array $in): array {
  $name = trim($in['name'] ?? ''); $email = trim($in['email'] ?? ''); $phone = trim($in['phone'] ?? ''); $addr = trim($in['address'] ?? ''); $bd = trim($in['birth_date'] ?? '');
  $raw = trim($in['license'] ?? ''); $exp = trim($in['license_expiry'] ?? ''); $emg = trim($in['emergency_contact'] ?? ''); $notes = trim($in['notes'] ?? '');
  if (strlen($name) < 2 || strlen($name) > 100 || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 120 || strlen($phone) < 7 || strlen($phone) > 30) fail('Check the name, email and phone number.');
  if (strlen($addr) > 200 || strlen($emg) > 120 || strlen($notes) > 500) fail('One of the text fields is too long.');
  if ($bd !== '' && (!date_ok($bd) || $bd > date('Y-m-d', strtotime('-16 years')) || $bd < '1920-01-01')) fail('Check the date of birth.');
  if ($exp !== '' && !date_ok($exp)) fail('Check the licence expiry date.');
  $lic = norm_license($raw); if (!$lic) fail(S('license.hint', 'Enter the licence number exactly as printed on the licence.'));
  return [$name, $email, $phone, $addr ?: null, $bd ?: null, $lic, $exp ?: null, $emg ?: null, $notes ?: null];
}
function cust_row(PDO $pdo, $id): array {
  $s = $pdo->prepare('SELECT * FROM customers WHERE id=?'); $s->execute([(int)$id]);
  return $s->fetch() ?: fail('Customer not found.', 404);
}
function cust_active(PDO $pdo, int $id): int {
  $s = $pdo->prepare("SELECT COUNT(*) FROM bookings WHERE customer_id=? AND status IN ('reserved','picked')"); $s->execute([$id]); return (int)$s->fetchColumn();
}

function pay_mode(): string { return S('payments.mode') === 'paymongo' && S('payments.paymongo.secret_key') ? 'paymongo' : 'manual'; }
function recalc_booking(PDO $pdo, int $id): void {   // bookings.paid / refunded are totals of the payments ledger
  $pdo->prepare("UPDATE bookings SET paid=(SELECT COALESCE(SUM(amount),0) FROM payments WHERE booking_id=? AND kind='payment' AND status='completed'), refunded=(SELECT COALESCE(SUM(amount),0) FROM payments WHERE booking_id=? AND kind='refund' AND status IN ('completed','pending')) WHERE id=?")->execute([$id, $id, $id]);
}
function pay_add(PDO $pdo, int $bid, string $kind, int $amt, string $method, string $status, string $note, ?string $ref, ?string $gw, ?string $by): int {
  $pdo->prepare('INSERT INTO payments (booking_id,kind,amount,method,status,note,reference,gateway_id,created_by) VALUES (?,?,?,?,?,?,?,?,?)')->execute([$bid, $kind, $amt, $method, $status, $note, $ref, $gw, $by]);
  $id = (int)$pdo->lastInsertId(); recalc_booking($pdo, $bid); return $id;
}
function cancel_booking(PDO $pdo, int $id, string $why): void {   // cancels and queues a refund of everything paid
  $pdo->prepare("UPDATE bookings SET status='cancelled' WHERE id=? AND status='reserved'")->execute([$id]);
  $s = $pdo->prepare('SELECT paid FROM bookings WHERE id=?'); $s->execute([$id]); $paid = (int)$s->fetchColumn();
  if ($paid > 0) pay_add($pdo, $id, 'refund', $paid, 'Refund', 'pending', $why, null, null, $_SESSION['admin'] ?? 'customer'); else recalc_booking($pdo, $id);
}
function doc_token(string $ref): string { return $ref . '.' . substr(hash_hmac('sha256', $ref, (string)S('secret')), 0, 24); }
function doc_ref(string $t): ?string {
  [$ref, $sig] = array_pad(explode('.', $t, 2), 2, '');
  return $ref !== '' && hash_equals(substr(hash_hmac('sha256', $ref, (string)S('secret')), 0, 24), $sig) ? $ref : null;
}
function next_doc(PDO $pdo, string $type, int $bid, int $pid = 0, bool $create = true): ?array {   // sequential document numbers, issued once
  $q = $pdo->prepare('SELECT * FROM documents WHERE booking_id=? AND doc_type=? AND payment_id=?'); $q->execute([$bid, $type, $pid]);
  if ($d = $q->fetch()) return $d; if (!$create) return null;
  $cfg = S("documents.$type", []); $start = max(1, (int)($cfg['start'] ?? 1)); $own = !$pdo->inTransaction(); if ($own) $pdo->beginTransaction();
  try {
    $r = $pdo->prepare('INSERT INTO doc_counters (doc_type,last_seq) VALUES (?,?) ON DUPLICATE KEY UPDATE last_seq=LAST_INSERT_ID(last_seq+1)'); $r->execute([$type, $start]);
    $seq = $r->rowCount() === 1 ? $start : (int)$pdo->lastInsertId();
    $num = ($cfg['prefix'] ?? '') . (!empty($cfg['use_year']) ? date('Y') . '-' : '') . str_pad((string)$seq, (int)($cfg['digits'] ?? 6), '0', STR_PAD_LEFT);
    $pdo->prepare('INSERT INTO documents (doc_type,seq,number,booking_id,payment_id) VALUES (?,?,?,?,?)')->execute([$type, $seq, $num, $bid, $pid]);
    if ($own) $pdo->commit();
  } catch (PDOException $e) {
    if ($own && $pdo->inTransaction()) $pdo->rollBack();
    if ($e->getCode() === '23000') { $q->execute([$bid, $type, $pid]); if ($d = $q->fetch()) return $d; }
    throw $e;
  }
  $q->execute([$bid, $type, $pid]); return $q->fetch() ?: null;
}

// ---- PayMongo (online payments). Field names follow PayMongo's public docs: test in their test mode before going live. ----
function pm(string $method, string $path, ?array $body = null): array {
  $ch = curl_init('https://api.paymongo.com/v1' . $path);
  $o = [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20, CURLOPT_CUSTOMREQUEST => $method, CURLOPT_USERPWD => S('payments.paymongo.secret_key') . ':', CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Accept: application/json']];
  if ($body !== null) $o[CURLOPT_POSTFIELDS] = json_encode($body);
  curl_setopt_array($ch, $o); $raw = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $err = curl_error($ch); curl_close($ch);
  $j = json_decode((string)$raw, true);
  if ($code >= 400 || !is_array($j)) throw new RuntimeException("PayMongo error ($code) $err " . substr((string)$raw, 0, 300));
  return $j;
}
function pm_checkout(string $ref, int $amount): array {
  $j = pm('POST', '/checkout_sessions', ['data' => ['attributes' => [
    'line_items' => [['currency' => 'PHP', 'amount' => $amount * 100, 'name' => 'Car rental booking ' . $ref, 'quantity' => 1]],
    'payment_method_types' => S('payments.paymongo.methods', ['gcash', 'card']), 'description' => 'Booking ' . $ref, 'reference_number' => $ref,
    'success_url' => S('site_url') . '/index.html#/paid/' . rawurlencode(doc_token($ref)), 'cancel_url' => S('site_url') . '/index.html#/mine',
    'send_email_receipt' => false, 'show_description' => true, 'show_line_items' => true]]]);
  return ['id' => $j['data']['id'], 'url' => $j['data']['attributes']['checkout_url']];
}
function pm_settle(PDO $pdo, string $sessionId): int {   // asks PayMongo what was really paid, and records it once
  $a = pm('GET', '/checkout_sessions/' . rawurlencode($sessionId))['data']['attributes'] ?? [];
  $s = $pdo->prepare('SELECT * FROM bookings WHERE ref=? OR gateway_ref=? LIMIT 1'); $s->execute([$a['reference_number'] ?? '', $sessionId]); $b = $s->fetch(); if (!$b) return 0;
  foreach ($a['payments'] ?? [] as $p) {
    $pa = $p['attributes'] ?? []; $gw = $p['id'] ?? ''; $amt = (int)round(($pa['amount'] ?? 0) / 100);
    if (($pa['status'] ?? '') !== 'paid' || $gw === '' || $amt < 1) continue;
    $x = $pdo->prepare('SELECT 1 FROM payments WHERE gateway_id=?'); $x->execute([$gw]); if ($x->fetchColumn()) continue;
    try { pay_add($pdo, (int)$b['id'], 'payment', $amt, ucfirst((string)($pa['source']['type'] ?? 'online')), 'completed', 'Paid online through PayMongo', $gw, $gw, 'paymongo'); }
    catch (PDOException $e) { if ($e->getCode() === '23000') continue; throw $e; }
    if ($b['status'] === 'cancelled') pay_add($pdo, (int)$b['id'], 'refund', $amt, 'Refund', 'pending', 'Paid after the booking was released', null, null, 'paymongo');
    else notify($pdo, (int)$b['id'], 'payment', $amt);
  }
  return (int)$b['id'];
}

// ---- email ----
function smtp_send(array $c, string $from, string $to, string $head, string $enc): bool {
  $f = @stream_socket_client(($c['security'] === 'ssl' ? 'ssl://' : '') . $c['host'] . ':' . $c['port'], $en, $es, 15); if (!$f) return false;
  $rd = function () use ($f) { $r = ''; while (($l = fgets($f, 515)) !== false) { $r .= $l; if (isset($l[3]) && $l[3] === ' ') break; } return $r; };
  $ok = fn(string $r, array $codes) => in_array(substr($r, 0, 3), $codes, true);
  $rd(); fwrite($f, "EHLO localhost\r\n"); $rd();
  if ($c['security'] === 'tls') {
    fwrite($f, "STARTTLS\r\n"); if (!$ok($rd(), ['220']) || !stream_socket_enable_crypto($f, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) return false;
    fwrite($f, "EHLO localhost\r\n"); $rd();
  }
  if (($c['user'] ?? '') !== '') { fwrite($f, "AUTH LOGIN\r\n"); $rd(); fwrite($f, base64_encode($c['user']) . "\r\n"); $rd(); fwrite($f, base64_encode($c['pass']) . "\r\n"); if (!$ok($rd(), ['235'])) return false; }
  fwrite($f, "MAIL FROM:<$from>\r\n"); if (!$ok($rd(), ['250'])) return false;
  fwrite($f, "RCPT TO:<$to>\r\n"); if (!$ok($rd(), ['250', '251'])) return false;
  fwrite($f, "DATA\r\n"); if (!$ok($rd(), ['354'])) return false;
  fwrite($f, $head . "\r\n\r\n" . $enc . "\r\n.\r\n"); $good = $ok($rd(), ['250']); fwrite($f, "QUIT\r\n"); fclose($f); return $good;
}
function send_mail(string $to, string $subject, string $body): bool {
  $m = S('mail', []); $mode = $m['mode'] ?? 'log'; $to = str_replace(["\r", "\n"], '', $to);
  if ($mode === 'log') {
    if (!is_dir(PRIVATE_DIR)) @mkdir(PRIVATE_DIR, 0750, true);
    return file_put_contents(PRIVATE_DIR . '/mail.log', date('c') . "\nTo: $to\nSubject: $subject\n\n$body\n" . str_repeat('-', 60) . "\n", FILE_APPEND) !== false;
  }
  $from = str_replace(["\r", "\n"], '', $m['from'] ?? ''); $subj = '=?UTF-8?B?' . base64_encode($subject) . '?=';
  $head = 'From: =?UTF-8?B?' . base64_encode($m['from_name'] ?? '') . "?= <$from>\r\nTo: <$to>\r\nSubject: $subj\r\nDate: " . date('r') . "\r\nMIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64";
  $enc = chunk_split(base64_encode($body));
  if ($mode === 'mail') return @mail($to, $subj, $enc, preg_replace('/^(To|Subject): .*\r\n/m', '', $head));
  return smtp_send($m['smtp'] ?? [], $from, $to, $head, $enc);
}
function notify(PDO $pdo, int $bid, string $event, int $amount = 0): void {   // never lets an email problem break a booking
  try {
    $s = $pdo->prepare('SELECT b.*, c.name AS car FROM bookings b JOIN cars c ON c.id=b.car_id WHERE b.id=?'); $s->execute([$bid]); $b = $s->fetch();
    if (!$b || !filter_var($b['email'], FILTER_VALIDATE_EMAIL) || strpos($b['email'], '@invalid.local') !== false) return;
    $biz = S('business.name', 'RoadKey'); $link = S('site_url') . '/invoice.html?t=' . rawurlencode(doc_token($b['ref'])); $php = fn($n) => '₱' . number_format((int)$n);
    $info = "Booking: {$b['ref']}\nCar: {$b['car']}\nDates: {$b['date_from']} to {$b['date_to']}\nRental total: " . $php($b['total']) . "\n";
    if ($event === 'booked') {
      $subject = "Booking {$b['ref']} received";
      $how = pay_mode() === 'paymongo' ? "We are waiting for your online payment of " . $php($b['due_now']) . ". If it did not go through, open My bookings on our site and choose Pay now before the hold runs out.\n"
                                       : "Please pay " . $php($b['due_now']) . " at pickup (this includes the " . $php($b['deposit']) . " refundable deposit) and bring your driver's licence.\n";
      $text = "Hello {$b['name']},\n\nThank you for booking with $biz.\n\n$info\n$how\nYour invoice: $link\n";
    } elseif ($event === 'payment') { $subject = "Payment received for {$b['ref']}"; $text = "Hello {$b['name']},\n\nWe received your payment of " . $php($amount) . ".\n\n$info\nInvoice and receipts: $link\n"; }
    else { $subject = "Booking {$b['ref']} cancelled"; $text = "Hello {$b['name']},\n\nYour booking {$b['ref']} was cancelled. Anything you paid (" . $php($b['paid']) . ") will be refunded.\n\nDetails: $link\n"; }
    send_mail($b['email'], $subject, $text . "\n$biz\n");
  } catch (Throwable $e) { error_log('mail: ' . $e->getMessage()); }
}

function invoice_data(PDO $pdo, array $b, bool $admin): array {
  $s = $pdo->prepare("SELECT * FROM booking_items WHERE booking_id=? AND kind='charge' ORDER BY id"); $s->execute([$b['id']]); $items = $s->fetchAll();
  $cancelled = $b['status'] === 'cancelled'; $lines = [];
  if (!$cancelled) {
    $days = (new DateTime($b['date_from']))->diff(new DateTime($b['date_to']))->days;
    if ($b['daily_rate'] !== null) {
      $lines[] = ['d' => "Car rental: {$b['car']}, $days day(s) at ₱" . number_format((int)$b['daily_rate']) . ' per day', 'a' => $days * (int)$b['daily_rate']];
      if ($b['surcharge'] > 0) $lines[] = ['d' => 'Weekend rate surcharge (+15% on Friday and Saturday nights)', 'a' => (int)$b['surcharge']];
      if ($b['discount'] > 0) $lines[] = ['d' => 'Long-stay discount (10% for 7 days or more)', 'a' => -(int)$b['discount']];
    } else $lines[] = ['d' => "Car rental: {$b['car']}, $days day(s)", 'a' => (int)$b['total']];
    if ($b['fee'] > 0) $lines[] = ['d' => 'Late return fee (1.5 times the daily rate for each day late)', 'a' => (int)$b['fee']];
    foreach ($items as $i) $lines[] = ['d' => $i['description'], 'a' => (int)$i['amount'], 'id' => $admin ? (int)$i['id'] : null];
  }
  $total = array_sum(array_column($lines, 'a')); $settled = in_array($b['status'], ['returned', 'cancelled'], true);
  $s = $pdo->prepare("SELECT * FROM payments WHERE booking_id=? AND status<>'void' ORDER BY id"); $s->execute([$b['id']]); $rc = (bool)S('documents.receipt.enabled', false); $pays = [];
  foreach ($s->fetchAll() as $p) {
    $rec = null; if ($rc && $p['kind'] === 'payment' && $p['status'] === 'completed') $rec = (next_doc($pdo, 'receipt', (int)$b['id'], (int)$p['id']) ?? [])['number'] ?? null;
    $pays[] = ['id' => (int)$p['id'], 'kind' => $p['kind'], 'status' => $p['status'], 'a' => (int)$p['amount'], 't' => substr($p['created_at'], 0, 10), 'method' => $p['method'], 'ref' => $p['reference'], 'note' => $p['note'], 'receipt' => $rec, 'gateway' => (bool)$p['gateway_id']];
  }
  $paid = (int)$b['paid']; $refunded = (int)$b['refunded']; $held = $settled ? 0 : min($paid, (int)$b['deposit']); $received = $paid - ($settled ? $refunded : $held); $balance = $total - $received;
  $mode = S('tax.mode', 'none'); $rate = (float)S('tax.rate', 0.12); $vat = $mode === 'inclusive' ? (int)round($total * $rate / (1 + $rate)) : 0;
  $doc = $cancelled ? next_doc($pdo, 'invoice', (int)$b['id'], 0, false) : next_doc($pdo, 'invoice', (int)$b['id']);
  return ['no' => $doc['number'] ?? null, 'title' => S('documents.invoice.title', 'Invoice'), 'receipt_title' => S('documents.receipt.title', 'Receipt'), 'draft' => (bool)S('documents.draft_notice', true), 'footer' => S('documents.footer', ''),
    'issued' => $doc ? substr($doc['issued_at'], 0, 10) : date('Y-m-d'), 'business' => S('business', []), 'tax' => ['mode' => $mode, 'label' => S('tax.label', 'VAT'), 'rate' => $rate, 'vat' => $vat],
    'booking' => ['id' => $admin ? (int)$b['id'] : null, 'ref' => $b['ref'], 'car' => $b['car'], 'plate' => $b['plate'], 'from' => $b['date_from'], 'to' => $b['date_to'], 'status' => $b['status']],
    'customer' => ['name' => $b['name'], 'email' => $b['email'], 'phone' => $b['phone']], 'lines' => $lines, 'total' => $total, 'payments' => $pays,
    'deposit_held' => $held, 'refunded' => $refunded, 'received' => $received, 'balance' => $balance, 'methods' => $admin ? S('payments.methods', []) : [], 'admin' => $admin,
    'state' => $cancelled ? 'Cancelled' : ($balance > 0 ? 'Balance due' : ($balance < 0 ? 'Overpaid' : 'Paid in full'))];
}
const INV_SQL = 'SELECT b.*, c.name AS car, c.plate FROM bookings b JOIN cars c ON c.id=b.car_id WHERE ';

$r = $_GET['r'] ?? ''; $post = $_SERVER['REQUEST_METHOD'] === 'POST';
if ($post && !in_array($r, ['book', 'admin_car_photo', 'webhook'], true) && stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') === false) fail('Unsupported request.', 415);
$in = $post && !in_array($r, ['book', 'admin_car_photo', 'webhook'], true) ? (json_decode(file_get_contents('php://input'), true) ?: []) : [];

try {
  $pdo = db();
  $pdo->exec("UPDATE bookings SET status='cancelled' WHERE status='reserved' AND paid=0 AND hold_until IS NOT NULL AND hold_until < NOW()");   // release unpaid online holds
  switch ($r) {
    case 'cars':
      $f = $_GET['from'] ?? ''; $t = $_GET['to'] ?? ''; $b = $_GET['branch'] ?? ''; dates($f, $t);
      $s = $pdo->prepare("SELECT c.id, c.name, c.type, c.seats, c.rate, c.branch, c.photo FROM cars c WHERE c.status='ok' AND (?='' OR c.branch=?) AND " . FREE . " ORDER BY c.branch, c.rate");
      $s->execute([$b, $b, $t, $f, $t, $f]);
      $rows = $s->fetchAll(); foreach ($rows as &$c) $c['quote'] = quote($c['rate'], $f, $t);
      out($rows);
    case 'car':
      $s = $pdo->prepare('SELECT * FROM cars WHERE id=?'); $s->execute([(int)($_GET['id'] ?? 0)]); $c = $s->fetch();
      if (!$c || $c['status'] === 'retired') fail('Vehicle not found.', 404);
      unset($c['plate'], $c['mileage']);
      $f = $_GET['from'] ?? ''; $t = $_GET['to'] ?? '';
      if (date_ok($f) && date_ok($t) && $t > $f) $c['quote'] = quote($c['rate'], $f, $t);
      out($c);
    case 'book':
      $f = $_POST['from'] ?? ''; $t = $_POST['to'] ?? ''; dates($f, $t);
      $name = trim($_POST['name'] ?? ''); $email = trim($_POST['email'] ?? ''); $phone = trim($_POST['phone'] ?? ''); $exp = $_POST['license_expiry'] ?? '';
      if (strlen($name) < 2 || strlen($name) > 100 || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($phone) < 7 || strlen($phone) > 30) fail('Please fill in every field correctly.');
      $lic = norm_license((string)($_POST['license'] ?? '')); if (!$lic) fail(S('license.hint', 'Enter the licence number exactly as printed on the licence.'));
      if (!date_ok($exp) || $exp > date('Y-m-d', strtotime('+11 years'))) fail('Enter your licence expiry date.');
      if ($exp < $t) fail('Your licence must still be valid on the return date.');
      if (empty($_POST['consent'])) fail('Please agree to the licence photo notice.');
      $s = $pdo->prepare('SELECT 1 FROM blocked_licenses WHERE license=?'); $s->execute([$lic]);
      if ($s->fetchColumn()) fail('We are unable to accept this booking. Please contact the branch.', 403);
      $s = $pdo->prepare("SELECT COUNT(*) FROM bookings WHERE license=? AND status<>'cancelled' AND (LOWER(email)<>LOWER(?) OR LOWER(name)<>LOWER(?))"); $s->execute([$lic, $email, $name]);
      $flag = (int)$s->fetchColumn() ? 'Same licence used with a different name or email' : null;
      $pdo->beginTransaction();
      $s = $pdo->prepare("SELECT * FROM cars WHERE id=? AND status='ok' FOR UPDATE"); $s->execute([(int)($_POST['car_id'] ?? 0)]); $c = $s->fetch();
      if (!$c) { $pdo->rollBack(); fail('This car is not available.'); }
      $s = $pdo->prepare('SELECT COUNT(*) FROM cars c WHERE c.id=? AND ' . FREE); $s->execute([$c['id'], $t, $f, $t, $f]);
      if (!(int)$s->fetchColumn()) { $pdo->rollBack(); fail('Sorry, this car was just taken on those dates.', 409); }
      $pdo->prepare('INSERT INTO customers (name,email,phone,license,license_expiry) VALUES (?,?,?,?,?) ON DUPLICATE KEY UPDATE phone=VALUES(phone), license=VALUES(license), license_expiry=VALUES(license_expiry)')->execute([$name, $email, $phone, $lic, $exp]);
      $s = $pdo->prepare('SELECT id FROM customers WHERE email=?'); $s->execute([$email]); $cid = (int)$s->fetchColumn();
      $photo = save_photo('license_photo', true); $selfie = save_photo('selfie_photo', false);
      $q = quote($c['rate'], $f, $t); $due = DEPOSIT + (!empty($_POST['pay_full']) ? $q['total'] : 0); $ref = 'BK' . strtoupper(bin2hex(random_bytes(3)));
      $pdo->prepare('INSERT INTO bookings (ref,car_id,name,email,phone,license,license_expiry,license_photo,selfie_photo,flag,date_from,date_to,total,deposit,paid,customer_id,daily_rate,surcharge,discount,due_now) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
          ->execute([$ref, $c['id'], $name, $email, $phone, $lic, $exp, $photo, $selfie, $flag, $f, $t, $q['total'], DEPOSIT, 0, $cid, $c['rate'], $q['surcharge'], $q['discount'], $due]);
      $bid = (int)$pdo->lastInsertId(); $pdo->commit();
      $res = ['ref' => $ref, 'total' => $q['total'], 'due' => $due, 'checkout_url' => null];
      if (pay_mode() === 'paymongo') {
        try {
          $co = pm_checkout($ref, $due);
          $pdo->prepare('UPDATE bookings SET gateway_ref=?, hold_until=NOW() + INTERVAL ? MINUTE WHERE id=?')->execute([$co['id'], (int)S('payments.hold_minutes', 30), $bid]); $res['checkout_url'] = $co['url'];
        } catch (Throwable $e) { error_log($e->getMessage()); $pdo->prepare("UPDATE bookings SET status='cancelled' WHERE id=?")->execute([$bid]); fail('Online payment is unavailable right now. Please try again later.', 502); }
      }
      notify($pdo, $bid, 'booked'); out($res);
    case 'lookup':
      $s = $pdo->prepare('SELECT b.ref, b.date_from, b.date_to, b.total, b.paid, b.refunded, b.fee, b.status, b.verified, b.due_now, c.name AS car FROM bookings b JOIN cars c ON c.id=b.car_id WHERE b.email=? AND b.ref=?');
      $s->execute([trim($_GET['email'] ?? ''), strtoupper(trim($_GET['ref'] ?? ''))]); $rows = $s->fetchAll(); foreach ($rows as &$row) $row['pay_online'] = pay_mode() === 'paymongo'; out($rows);
    case 'cancel':
      $e = trim($in['email'] ?? ''); $rf = strtoupper(trim($in['ref'] ?? ''));
      $s = $pdo->prepare("SELECT id FROM bookings WHERE email=? AND ref=? AND status='reserved'"); $s->execute([$e, $rf]); $id = (int)$s->fetchColumn();
      if (!$id) fail('This booking cannot be cancelled.');
      cancel_booking($pdo, $id, 'Cancelled by customer'); drop_photos($pdo, $id); notify($pdo, $id, 'cancelled'); out(['ok' => 1]);

    case 'login':
      if (($_SESSION['lock'] ?? 0) > time()) fail('Too many attempts. Wait a minute and try again.', 429);
      $s = $pdo->prepare('SELECT * FROM admins WHERE username=?'); $s->execute([trim($in['user'] ?? '')]); $a = $s->fetch();
      if ($a && password_verify((string)($in['password'] ?? ''), $a['password_hash'])) { session_regenerate_id(true); $_SESSION = ['admin' => $a['username']]; out(['ok' => 1]); }
      $_SESSION['tries'] = ($_SESSION['tries'] ?? 0) + 1;
      if ($_SESSION['tries'] >= 5) { $_SESSION['lock'] = time() + 60; $_SESSION['tries'] = 0; }
      sleep(1); fail('Wrong username or password.', 401);
    case 'logout': session_destroy(); out(['ok' => 1]);
    case 'me': need_admin(); out(['user' => $_SESSION['admin']]);

    case 'admin_stats':
      need_admin();
      $n = fn($sql) => (int)$pdo->query($sql)->fetchColumn();
      out(['net' => $n('SELECT COALESCE(SUM(paid-refunded),0) FROM bookings'), 'out' => $n("SELECT COUNT(*) FROM bookings WHERE status='picked'"),
           'overdue' => $n("SELECT COUNT(*) FROM bookings WHERE status='picked' AND date_to < CURDATE()"), 'waiting' => $n("SELECT COUNT(*) FROM bookings WHERE status='reserved'"),
           'maint' => $n("SELECT COUNT(*) FROM cars c WHERE c.status='maint' OR EXISTS (SELECT 1 FROM maintenance m WHERE m.car_id=c.id AND m.status='scheduled' AND CURDATE() BETWEEN m.date_from AND m.date_to)"), 'refunds' => $n("SELECT COUNT(*) FROM payments WHERE kind='refund' AND status='pending'"), 'cars' => $n("SELECT COUNT(*) FROM cars WHERE status<>'retired'"),
           'branches' => $pdo->query("SELECT c.branch, COALESCE(SUM(b.total+b.fee),0) AS value FROM cars c LEFT JOIN bookings b ON b.car_id=c.id AND b.status<>'cancelled' GROUP BY c.branch")->fetchAll()]);
    case 'admin_bookings':
      need_admin();
      out($pdo->query("SELECT b.*, c.name AS car, IF(b.status='picked' AND b.date_to<CURDATE(), DATEDIFF(CURDATE(), b.date_to), 0) AS late FROM bookings b JOIN cars c ON c.id=b.car_id ORDER BY b.id DESC")->fetchAll());
    case 'admin_status':
      need_admin(); $pdo->beginTransaction();
      $s = $pdo->prepare('SELECT b.*, c.rate, c.mileage AS car_km FROM bookings b JOIN cars c ON c.id=b.car_id WHERE b.id=? FOR UPDATE'); $s->execute([(int)($in['id'] ?? 0)]); $b = $s->fetch();
      if (!$b) { $pdo->rollBack(); fail('Booking not found.', 404); }
      if ($b['status'] === 'reserved') {
        if (!$b['verified']) { $pdo->rollBack(); fail('Verify the driver’s licence first.'); }
        if (S('payments.require_deposit_before_pickup', true) && (int)$b['paid'] < (int)$b['deposit']) { $pdo->rollBack(); fail('Record the deposit payment first (₱' . number_format((int)$b['deposit']) . ').'); }
        $pdo->prepare("UPDATE bookings SET status='picked' WHERE id=?")->execute([$b['id']]);
      }
      elseif ($b['status'] === 'picked') {
        $diff = (new DateTime($b['date_to']))->diff(new DateTime('today')); $late = $diff->invert ? 0 : $diff->days;
        $fee = (int)round($late * $b['rate'] * 1.5);
        $km = (int)($in['km'] ?? 0);
        if ($km < (int)$b['car_km']) { $pdo->rollBack(); fail('Enter the odometer reading. It cannot be lower than ' . $b['car_km'] . ' km.'); }
        $pdo->prepare('UPDATE cars SET mileage=? WHERE id=?')->execute([$km, $b['car_id']]);
        $x = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM booking_items WHERE booking_id=? AND kind='charge'"); $x->execute([$b['id']]); $extra = (int)$x->fetchColumn();   // extra charges come out of the deposit
        $pdo->prepare("UPDATE bookings SET status='returned', fee=? WHERE id=?")->execute([$fee, $b['id']]);
        $back = max(0, min((int)$b['paid'], (int)$b['deposit']) - $fee - $extra);   // the deposit comes back, less late fees and extra charges
        if ($back > 0) pay_add($pdo, (int)$b['id'], 'refund', $back, 'Deposit refund', 'pending', 'Deposit refund after return', null, null, $_SESSION['admin']); else recalc_booking($pdo, (int)$b['id']);
      } else { $pdo->rollBack(); fail('Nothing to change for this booking.'); }
      $pdo->commit(); if ($b['status'] === 'picked') drop_photos($pdo, (int)$b['id']); out(['ok' => 1]);
    case 'admin_cars':
      need_admin();
      out($pdo->query("SELECT c.*, (SELECT COUNT(*) FROM bookings b WHERE b.car_id=c.id AND b.status IN ('reserved','picked')) AS active, (SELECT COUNT(*) FROM bookings b WHERE b.car_id=c.id) AS history, (SELECT COUNT(*) FROM maintenance m WHERE m.car_id=c.id AND m.status='scheduled' AND CURDATE() BETWEEN m.date_from AND m.date_to) AS in_shop, (SELECT MIN(m.date_from) FROM maintenance m WHERE m.car_id=c.id AND m.status='scheduled' AND m.date_to >= CURDATE()) AS next_maint FROM cars c ORDER BY c.status='retired', c.branch, c.name")->fetchAll());
    case 'admin_car_add':
      need_admin();
      try { $pdo->prepare('INSERT INTO cars (name,type,seats,rate,branch,plate,mileage) VALUES (?,?,?,?,?,?,?)')->execute(car_fields($in)); }
      catch (PDOException $e) { if ($e->getCode() === '23000') fail('That plate number is already in use.'); throw $e; }
      out(['ok' => 1]);
    case 'admin_car_edit':
      need_admin(); $c = car_row($pdo, $in); [$name, $type, $seats, $rate, $br, $plate, $km] = car_fields($in);
      if ($br !== $c['branch'] && car_bookings($pdo, $c['id'], ACTIVE)) fail('Move this car to another branch only after its current and upcoming bookings are finished.');
      try { $pdo->prepare('UPDATE cars SET name=?, type=?, seats=?, rate=?, branch=?, plate=?, mileage=? WHERE id=?')->execute([$name, $type, $seats, $rate, $br, $plate, $km, $c['id']]); }
      catch (PDOException $e) { if ($e->getCode() === '23000') fail('That plate number is already in use.'); throw $e; }
      out(['ok' => 1]);
    case 'admin_car_toggle':
      need_admin(); $c = car_row($pdo, $in);
      if ($c['status'] === 'retired') fail('Restore this vehicle first.');
      if ($c['status'] === 'ok' && car_bookings($pdo, $c['id'], "'picked'")) fail('This car is out on a rental right now.');
      $pdo->prepare("UPDATE cars SET status=IF(status='ok','maint','ok') WHERE id=?")->execute([$c['id']]); out(['ok' => 1]);
    case 'admin_car_retire':
      need_admin(); $c = car_row($pdo, $in);
      if (car_bookings($pdo, $c['id'], ACTIVE)) fail('This car has current or upcoming bookings. Finish or cancel them first.');
      $pdo->prepare("UPDATE cars SET status='retired' WHERE id=?")->execute([$c['id']]); out(['ok' => 1]);
    case 'admin_car_restore':
      need_admin(); $c = car_row($pdo, $in); $pdo->prepare("UPDATE cars SET status='ok' WHERE id=? AND status='retired'")->execute([$c['id']]); out(['ok' => 1]);
    case 'admin_car_delete':
      need_admin(); $c = car_row($pdo, $in);
      if (car_bookings($pdo, $c['id'], "'reserved','picked','returned','cancelled'")) fail('This car has booking history, so it cannot be deleted. Retire it instead.');
      $s = $pdo->prepare('SELECT COUNT(*) FROM maintenance WHERE car_id=?'); $s->execute([$c['id']]);
      if ((int)$s->fetchColumn()) fail('This car has maintenance records, so it cannot be deleted. Retire it instead.');
      $pdo->prepare('DELETE FROM cars WHERE id=?')->execute([$c['id']]); out(['ok' => 1]);
    case 'admin_verify':
      need_admin(); $s = $pdo->prepare("UPDATE bookings SET verified=1, verified_by=?, verified_at=NOW() WHERE id=? AND status='reserved'");
      $s->execute([$_SESSION['admin'], (int)($in['id'] ?? 0)]); out(['ok' => 1]);
    case 'admin_block':
      need_admin(); $pdo->beginTransaction();
      $s = $pdo->prepare('SELECT * FROM bookings WHERE id=? FOR UPDATE'); $s->execute([(int)($in['id'] ?? 0)]); $b = $s->fetch();
      if (!$b) { $pdo->rollBack(); fail('Booking not found.', 404); }
      $pdo->prepare('INSERT IGNORE INTO blocked_licenses (license, reason) VALUES (?,?)')->execute([$b['license'], substr(trim($in['reason'] ?? '') ?: 'Blocked by staff', 0, 200)]);
      if ($b['status'] === 'reserved') cancel_booking($pdo, (int)$b['id'], 'Licence blocked');
      $pdo->commit(); if ($b['status'] === 'reserved') drop_photos($pdo, (int)$b['id']); out(['ok' => 1]);
    case 'admin_blocked': need_admin(); out($pdo->query('SELECT * FROM blocked_licenses ORDER BY id DESC')->fetchAll());
    case 'admin_block_add':
      need_admin(); $raw = trim($in['license'] ?? ''); $lic = norm_license($raw) ?? strtoupper($raw);
      if (strlen($lic) < 4 || strlen($lic) > 40) fail('Enter a licence number.');
      $pdo->prepare('INSERT IGNORE INTO blocked_licenses (license, reason) VALUES (?,?)')->execute([$lic, substr(trim($in['reason'] ?? '') ?: 'Blocked by staff', 0, 200)]); out(['ok' => 1]);
    case 'admin_unblock': need_admin(); $pdo->prepare('DELETE FROM blocked_licenses WHERE id=?')->execute([(int)($in['id'] ?? 0)]); out(['ok' => 1]);
    case 'admin_file':   // licence images are only served to signed-in staff
      need_admin(); $k = ($_GET['kind'] ?? '') === 'selfie' ? 'selfie_photo' : 'license_photo';
      $s = $pdo->prepare("SELECT $k FROM bookings WHERE id=?"); $s->execute([(int)($_GET['id'] ?? 0)]); $n = $s->fetchColumn();
      $p = $n ? PRIVATE_DIR . '/' . basename($n) : ''; if (!$p || !is_file($p)) fail('No photo on file.', 404);
      header('Content-Type: ' . (substr($p, -4) === '.png' ? 'image/png' : 'image/jpeg')); header('X-Content-Type-Options: nosniff'); header('Cache-Control: private, no-store');
      readfile($p); exit;
    case 'admin_car_photo':
      need_admin(); if (($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') !== 'roadkey') fail('Unsupported request.', 415);
      $c = car_row($pdo, $_POST); if (empty($_FILES['photo'])) fail('Choose a photo.');
      $name = save_car_photo($_FILES['photo']); if ($c['photo']) @unlink(dirname(__DIR__) . '/uploads/cars/' . basename($c['photo']));
      $pdo->prepare('UPDATE cars SET photo=? WHERE id=?')->execute([$name, $c['id']]); out(['photo' => $name]);
    case 'admin_car_photo_remove':
      need_admin(); $c = car_row($pdo, $in); if ($c['photo']) @unlink(dirname(__DIR__) . '/uploads/cars/' . basename($c['photo']));
      $pdo->prepare('UPDATE cars SET photo=NULL WHERE id=?')->execute([$c['id']]); out(['ok' => 1]);
    case 'admin_maint':
      need_admin(); out($pdo->query("SELECT m.*, c.name AS car, c.plate FROM maintenance m JOIN cars c ON c.id=m.car_id ORDER BY m.status='scheduled' DESC, m.date_from DESC")->fetchAll());
    case 'admin_maint_add':
      need_admin(); $c = car_row($pdo, ['id' => $in['car_id'] ?? 0]);
      $kind = $in['kind'] ?? ''; $f = $in['date_from'] ?? ''; $t = $in['date_to'] ?? ''; $notes = trim($in['notes'] ?? ''); $cost = (int)($in['cost'] ?? 0);
      if ($c['status'] === 'retired') fail('This vehicle is retired.');
      if (!in_array($kind, ['Scheduled service', 'Repair', 'Damage repair', 'Inspection'], true)) fail('Choose the type of work.');
      if (!date_ok($f) || !date_ok($t) || $t < $f) fail('Choose valid dates. The end cannot be before the start.');
      if ($t < date('Y-m-d')) fail('The period cannot be entirely in the past.');
      if ((new DateTime($f))->diff(new DateTime($t))->days > 90) fail('Maintenance cannot be longer than 90 days.');
      if (strlen($notes) > 300 || $cost < 0 || $cost > 10000000) fail('Check the notes and cost.');
      $pdo->beginTransaction(); $pdo->prepare('SELECT id FROM cars WHERE id=? FOR UPDATE')->execute([$c['id']]);   // same lock a booking takes
      $s = $pdo->prepare("SELECT ref FROM bookings WHERE car_id=? AND status IN ('reserved','picked') AND date_from <= ? AND ? < date_to"); $s->execute([$c['id'], $t, $f]); $refs = $s->fetchAll(PDO::FETCH_COLUMN);
      if ($refs) { $pdo->rollBack(); fail('Bookings are in the way: ' . implode(', ', $refs) . '. Cancel them or choose other dates.'); }
      $s = $pdo->prepare("SELECT COUNT(*) FROM maintenance WHERE car_id=? AND status='scheduled' AND date_from <= ? AND ? <= date_to"); $s->execute([$c['id'], $t, $f]);
      if ((int)$s->fetchColumn()) { $pdo->rollBack(); fail('This car already has maintenance planned in that period.'); }
      $pdo->prepare('INSERT INTO maintenance (car_id,kind,date_from,date_to,notes,cost,created_by) VALUES (?,?,?,?,?,?,?)')->execute([$c['id'], $kind, $f, $t, $notes, $cost, $_SESSION['admin']]);
      $pdo->commit(); out(['ok' => 1]);
    case 'admin_maint_status':
      need_admin(); $st = $in['status'] ?? ''; if (!in_array($st, ['done', 'cancelled'], true)) fail('Unknown action.');
      $pdo->prepare("UPDATE maintenance SET status=? WHERE id=? AND status='scheduled'")->execute([$st, (int)($in['id'] ?? 0)]); out(['ok' => 1]);
    case 'admin_customers':
      need_admin(); $q = trim($_GET['q'] ?? ''); $like = '%' . addcslashes($q, '%_\\') . '%';
      $s = $pdo->prepare("SELECT c.*, (SELECT COUNT(*) FROM bookings b WHERE b.customer_id=c.id AND b.status<>'cancelled') AS rentals,
          (SELECT COALESCE(SUM(b.total+b.fee),0) FROM bookings b WHERE b.customer_id=c.id AND b.status<>'cancelled') AS spent,
          (SELECT MAX(b.date_from) FROM bookings b WHERE b.customer_id=c.id AND b.status<>'cancelled') AS last_rental,
          EXISTS(SELECT 1 FROM blocked_licenses bl WHERE bl.license=c.license) AS blocked,
          (SELECT COUNT(*) FROM customers d WHERE d.license=c.license AND d.id<>c.id) AS dup
        FROM customers c WHERE (?='' OR c.name LIKE ? OR c.email LIKE ? OR c.phone LIKE ? OR c.license LIKE ?) ORDER BY c.name LIMIT 300");
      $s->execute([$q, $like, $like, $like, $like]); out($s->fetchAll());
    case 'admin_customer':
      need_admin(); $c = cust_row($pdo, $_GET['id'] ?? 0);
      $b = $pdo->prepare('SELECT b.ref, b.date_from, b.date_to, b.total, b.fee, b.status, k.name AS car FROM bookings b JOIN cars k ON k.id=b.car_id WHERE b.customer_id=? ORDER BY b.id DESC'); $b->execute([$c['id']]);
      $x = $pdo->prepare('SELECT COUNT(*) FROM blocked_licenses WHERE license=?'); $x->execute([$c['license']]);
      $d = $pdo->prepare('SELECT COUNT(*) FROM customers WHERE license=? AND id<>?'); $d->execute([$c['license'], $c['id']]);
      out(['customer' => $c, 'bookings' => $b->fetchAll(), 'blocked' => (int)$x->fetchColumn() > 0, 'dup' => (int)$d->fetchColumn()]);
    case 'admin_customer_save':
      need_admin(); $id = (int)($in['id'] ?? 0); [$name, $email, $phone, $addr, $bd, $lic, $exp, $emg, $notes] = cust_fields($in);
      $pdo->beginTransaction();
      $s = $pdo->prepare('SELECT * FROM customers WHERE id=? FOR UPDATE'); $s->execute([$id]); $c = $s->fetch();
      if (!$c) { $pdo->rollBack(); fail('Customer not found.', 404); }
      if (strpos($c['license'], 'ERASED-') === 0) { $pdo->rollBack(); fail('This customer’s personal data has been erased.'); }
      try { $pdo->prepare('UPDATE customers SET name=?, email=?, phone=?, address=?, birth_date=?, license=?, license_expiry=?, emergency_contact=?, notes=? WHERE id=?')->execute([$name, $email, $phone, $addr, $bd, $lic, $exp, $emg, $notes, $id]); }
      catch (PDOException $e) { $pdo->rollBack(); if ($e->getCode() === '23000') fail('That email already belongs to another customer.'); throw $e; }
      $pdo->prepare('UPDATE bookings SET email=? WHERE customer_id=?')->execute([$email, $id]);
      $pdo->prepare("UPDATE bookings SET name=?, phone=? WHERE customer_id=? AND status IN ('reserved','picked')")->execute([$name, $phone, $id]);
      if ($lic !== $c['license'] || $exp !== $c['license_expiry'])   // a changed licence must be checked again before keys are handed over
        $pdo->prepare("UPDATE bookings SET license=?, license_expiry=?, verified=0, verified_by=NULL, verified_at=NULL WHERE customer_id=? AND status='reserved'")->execute([$lic, $exp, $id]);
      $pdo->commit(); out(['ok' => 1]);
    case 'admin_customer_block':
      need_admin(); $c = cust_row($pdo, $in['id'] ?? 0);
      $pdo->prepare('INSERT IGNORE INTO blocked_licenses (license, reason) VALUES (?,?)')->execute([$c['license'], substr(trim($in['reason'] ?? '') ?: 'Blocked by staff', 0, 200)]);
      $q = $pdo->prepare("SELECT id FROM bookings WHERE customer_id=? AND status='reserved'"); $q->execute([$c['id']]); $ids = $q->fetchAll(PDO::FETCH_COLUMN);
      foreach ($ids as $bid) cancel_booking($pdo, (int)$bid, 'Licence blocked');
      foreach ($ids as $bid) drop_photos($pdo, (int)$bid);
      out(['ok' => 1, 'cancelled' => count($ids)]);
    case 'admin_customer_unblock':
      need_admin(); $c = cust_row($pdo, $in['id'] ?? 0); $pdo->prepare('DELETE FROM blocked_licenses WHERE license=?')->execute([$c['license']]); out(['ok' => 1]);
    case 'admin_customer_erase':   // erase personal data; financial rows stay, without names
      need_admin(); $c = cust_row($pdo, $in['id'] ?? 0);
      if (strpos($c['license'], 'ERASED-') === 0) fail('This customer is already erased.');
      if (cust_active($pdo, $c['id'])) fail('This customer has a current or upcoming booking. Finish or cancel it first.');
      $q = $pdo->prepare('SELECT id FROM bookings WHERE customer_id=?'); $q->execute([$c['id']]); $ids = $q->fetchAll(PDO::FETCH_COLUMN);
      $pdo->beginTransaction();
      if (!$ids) $pdo->prepare('DELETE FROM customers WHERE id=?')->execute([$c['id']]);
      else {
        $pdo->prepare("UPDATE customers SET name='Erased customer', email=CONCAT('erased-', id, '@invalid.local'), phone='-', address=NULL, birth_date=NULL, license=CONCAT('ERASED-', id), license_expiry=NULL, emergency_contact=NULL, notes=NULL WHERE id=?")->execute([$c['id']]);
        $pdo->prepare("UPDATE bookings SET name='Erased customer', email=CONCAT('erased-', customer_id, '@invalid.local'), phone='-', license=CONCAT('ERASED-', customer_id), license_expiry=NULL, flag=NULL WHERE customer_id=?")->execute([$c['id']]);
      }
      $pdo->commit(); foreach ($ids as $bid) drop_photos($pdo, (int)$bid); out(['ok' => 1]);
    case 'invoice':
      $ref = ($_GET['t'] ?? '') !== '' ? doc_ref($_GET['t']) : null;
      if ($ref) { $s = $pdo->prepare(INV_SQL . 'b.ref=?'); $s->execute([$ref]); }
      else { $s = $pdo->prepare(INV_SQL . 'b.email=? AND b.ref=?'); $s->execute([trim($_GET['email'] ?? ''), strtoupper(trim($_GET['ref'] ?? ''))]); }
      $b = $s->fetch(); if (!$b) fail('No booking found. Check the link, or your email and reference.', 404); out(invoice_data($pdo, $b, false));
    case 'admin_invoice':
      need_admin(); $s = $pdo->prepare(INV_SQL . 'b.id=?'); $s->execute([(int)($_GET['id'] ?? 0)]); $b = $s->fetch();
      if (!$b) fail('Booking not found.', 404); out(invoice_data($pdo, $b, true));
    case 'admin_item_add':
      need_admin(); $desc = trim($in['description'] ?? ''); $amt = (int)round((float)($in['amount'] ?? 0));
      if (strlen($desc) < 2 || strlen($desc) > 120 || $amt < 1 || $amt > 1000000) fail('Enter a description and an amount from 1 to 1,000,000 pesos.');
      $s = $pdo->prepare('SELECT status FROM bookings WHERE id=?'); $s->execute([(int)($in['booking_id'] ?? 0)]); $st = $s->fetchColumn();
      if ($st === false) fail('Booking not found.', 404); if ($st === 'cancelled') fail('This booking was cancelled.');
      $pdo->prepare("INSERT INTO booking_items (booking_id,kind,description,amount,created_by) VALUES (?, 'charge', ?, ?, ?)")->execute([(int)$in['booking_id'], $desc, $amt, $_SESSION['admin']]); out(['ok' => 1]);
    case 'admin_item_delete': need_admin(); $pdo->prepare("DELETE FROM booking_items WHERE id=? AND kind='charge'")->execute([(int)($in['id'] ?? 0)]); out(['ok' => 1]);
    case 'admin_payment_add':
      need_admin(); $kind = $in['kind'] ?? ''; $method = $in['method'] ?? ''; $amt = (int)round((float)($in['amount'] ?? 0));
      if (!in_array($kind, ['payment', 'refund'], true) || !in_array($method, S('payments.methods', []), true) || $amt < 1 || $amt > 1000000) fail('Check the payment method and amount.');
      $pdo->beginTransaction(); $s = $pdo->prepare('SELECT * FROM bookings WHERE id=? FOR UPDATE'); $s->execute([(int)($in['booking_id'] ?? 0)]); $b = $s->fetch();
      if (!$b) { $pdo->rollBack(); fail('Booking not found.', 404); }
      if ($kind === 'payment' && $b['status'] === 'cancelled') { $pdo->rollBack(); fail('This booking was cancelled.'); }
      if ($kind === 'refund' && $amt > (int)$b['paid'] - (int)$b['refunded']) { $pdo->rollBack(); fail('That is more than the customer has paid and not yet been refunded.'); }
      pay_add($pdo, (int)$b['id'], $kind, $amt, $method, 'completed', substr(trim($in['note'] ?? ''), 0, 120), substr(trim($in['reference'] ?? ''), 0, 80) ?: null, null, $_SESSION['admin']);
      $pdo->commit(); if ($kind === 'payment') notify($pdo, (int)$b['id'], 'payment', $amt); out(['ok' => 1]);
    case 'admin_payment_update':
      need_admin(); $s = $pdo->prepare('SELECT * FROM payments WHERE id=?'); $s->execute([(int)($in['id'] ?? 0)]); $p = $s->fetch(); if (!$p) fail('Entry not found.', 404);
      $act = $in['action'] ?? '';
      if ($act === 'complete' && $p['kind'] === 'refund' && $p['status'] === 'pending') {
        $method = $in['method'] ?? ''; if (!in_array($method, S('payments.methods', []), true)) fail('Choose how the refund was sent.');
        $pdo->prepare("UPDATE payments SET status='completed', method=?, reference=? WHERE id=?")->execute([$method, substr(trim($in['reference'] ?? ''), 0, 80) ?: null, $p['id']]);
      } elseif ($act === 'void' && $p['status'] !== 'void' && !$p['gateway_id']) $pdo->prepare("UPDATE payments SET status='void' WHERE id=?")->execute([$p['id']]);
      else fail('Nothing to change on this entry.');
      recalc_booking($pdo, (int)$p['booking_id']); out(['ok' => 1]);
    case 'pay_verify':
      $ref = doc_ref($_GET['t'] ?? ''); if (!$ref) fail('This link is not valid.', 403);
      $s = $pdo->prepare('SELECT * FROM bookings WHERE ref=?'); $s->execute([$ref]); $b = $s->fetch(); if (!$b) fail('Booking not found.', 404);
      if ($b['gateway_ref'] && pay_mode() === 'paymongo') { try { pm_settle($pdo, $b['gateway_ref']); } catch (Throwable $e) { error_log($e->getMessage()); } $s->execute([$ref]); $b = $s->fetch(); }
      out(['ref' => $b['ref'], 'paid' => (int)$b['paid'], 'due' => (int)$b['due_now'], 'status' => $b['status']]);
    case 'pay_link':
      if (pay_mode() !== 'paymongo') fail('Online payment is not available.');
      $s = $pdo->prepare("SELECT * FROM bookings WHERE email=? AND ref=? AND status='reserved'"); $s->execute([trim($in['email'] ?? ''), strtoupper(trim($in['ref'] ?? ''))]); $b = $s->fetch();
      if (!$b || (int)$b['paid'] >= (int)$b['due_now']) fail('There is nothing left to pay on this booking.');
      try { $co = pm_checkout($b['ref'], (int)$b['due_now'] - (int)$b['paid']); }
      catch (Throwable $e) { error_log($e->getMessage()); fail('Online payment is unavailable right now. Please try again later.', 502); }
      $pdo->prepare('UPDATE bookings SET gateway_ref=?, hold_until=NOW() + INTERVAL ? MINUTE WHERE id=?')->execute([$co['id'], (int)S('payments.hold_minutes', 30), $b['id']]); out(['url' => $co['url']]);
    case 'webhook':   // PayMongo calls this. The payload is only a hint: we ask PayMongo what was really paid.
      $raw = file_get_contents('php://input'); $secret = (string)S('payments.paymongo.webhook_secret', ''); $sig = [];
      foreach (explode(',', $_SERVER['HTTP_PAYMONGO_SIGNATURE'] ?? '') as $kv) { $p = explode('=', $kv, 2); if (count($p) === 2) $sig[trim($p[0])] = trim($p[1]); }
      $want = hash_hmac('sha256', ($sig['t'] ?? '') . '.' . $raw, $secret);
      if ($secret === '' || !hash_equals($want, $sig[S('payments.paymongo.live') ? 'li' : 'te'] ?? '')) fail('Bad signature.', 403);
      $sid = json_decode($raw, true)['data']['attributes']['data']['id'] ?? ''; if (is_string($sid) && $sid !== '') { try { pm_settle($pdo, $sid); } catch (Throwable $e) { error_log($e->getMessage()); } }
      out(['ok' => 1]);
    default: fail('Unknown request.', 404);
  }
} catch (PDOException $e) {
  if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
  error_log($e->getMessage()); fail('Database error. Is MySQL running and database.sql imported?', 500);
}
