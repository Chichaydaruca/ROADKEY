<?php
// ============================================================================
//  RoadKey settings. Edit this file; nothing else needs to change.
//  Items marked ASK ACCOUNTANT are placeholders until you confirm them.
// ============================================================================
return [
  'site_url' => 'http://localhost/roadkey',            // no trailing slash. Used in emails and payment return links.
  'secret'   => 'CHANGE-ME-to-a-long-random-string',   // signs the invoice links that are emailed to customers.

  // Printed at the top of every invoice and receipt.
  'business' => [
    'name'            => 'RoadKey Car Rental',
    'registered_name' => '',            // ASK ACCOUNTANT: the exact registered business name (leave '' to use "name")
    'address'         => 'Your business address',
    'phone'           => '',
    'email'           => '',
    'tin'             => '',            // ASK ACCOUNTANT: your TIN
    'branch_code'     => '',            // ASK ACCOUNTANT: branch code, if you have one
  ],

  // Driver's licence number check. By default any 5 to 20 letters and numbers are accepted, because formats differ by licence type.
  // The real check is staff comparing the photo and the physical licence at pickup.
  'license' => [
    'pattern' => '',    // optional strict rule, a PHP regex tested against the number in capitals with no dashes or spaces, e.g. '/^[A-Z][0-9]{9}$/'
    'hint'    => 'Enter the licence number exactly as printed on your licence (letters and numbers, 5 to 20 characters).',
  ],

  'tax' => [
    // ASK ACCOUNTANT: 'none'      = not VAT-registered, no VAT shown
    //                 'inclusive' = VAT-registered and your prices already include VAT
    'mode'  => 'none',
    'rate'  => 0.12,
    'label' => 'VAT',
  ],

  'documents' => [
    // ASK ACCOUNTANT: which document you must issue, its exact title, and the numbering format.
    // Numbers are sequential and never reused. "start" only matters before the first document is issued.
    'invoice' => ['title' => 'Invoice',          'prefix' => 'INV-', 'digits' => 6, 'start' => 1, 'use_year' => false],
    'receipt' => ['title' => 'Official Receipt', 'prefix' => 'OR-',  'digits' => 6, 'start' => 1, 'use_year' => false,
                  'enabled' => false],   // true = every payment also gets a numbered receipt
    'draft_notice' => true,              // prints "not an official tax document" on every page. Set to false once your accountant approves the format.
    'footer'       => 'Thank you for renting with us.',
  ],

  'payments' => [
    'mode' => 'manual',                  // 'manual'   = staff record payments at the counter
                                         // 'paymongo' = customers pay online through PayMongo checkout
    'require_deposit_before_pickup' => true,
    'hold_minutes' => 30,                // paymongo mode: an unpaid booking is released after this long
    'methods' => ['Cash', 'GCash', 'Card', 'Bank transfer'],
    'paymongo' => [
      'secret_key'     => '',            // sk_test_... while testing, sk_live_... when you go live
      'webhook_secret' => '',            // optional, only works once the site is reachable from the internet
      'live'           => false,         // true when using live keys
      'methods'        => ['gcash', 'card', 'paymaya'],
    ],
  ],

  'mail' => [
    'mode'      => 'log',                // 'log'  = write emails to roadkey_private/mail.log (safe for testing)
                                         // 'mail' = PHP mail()   'smtp' = your mail provider (settings below)
    'from'      => 'bookings@example.com',
    'from_name' => 'RoadKey Car Rental',
    'smtp'      => ['host' => 'smtp.gmail.com', 'port' => 587, 'security' => 'tls', 'user' => '', 'pass' => ''],   // security: 'tls' (587) or 'ssl' (465)
  ],
];
