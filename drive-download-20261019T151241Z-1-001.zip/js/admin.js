const NAV = [['overview', 'Overview'], ['bookings', 'Bookings'], ['customers', 'Customers'], ['fleet', 'Fleet'], ['maintenance', 'Maintenance'], ['licences', 'Licences']], view = $('#view');
$('#out').onclick = async () => { await api('logout', { body: {} }); location.href = 'login.html'; };
async function render() {
  const [v, arg] = (location.hash.slice(2) || 'overview').split('/'); view.onclick = null;
  $('#nav').innerHTML = NAV.map(([k, l]) => `<a href="#/${k}" class="${k === v ? 'on' : ''}">${l}</a>`).join('');
  try { await ({ bookings, customers, fleet, maintenance, licences }[v] || overview)(arg); }
  catch (e) { if (e.status === 401) location.href = 'login.html'; else view.innerHTML = `<p class="err">${esc(e.message)}</p>`; }
}
async function overview() {
  const s = await api('admin_stats'), mx = Math.max(1, ...s.branches.map(b => +b.value));
  view.innerHTML = `<h1 style="font-size:2.2rem">Overview</h1><div class="nums"><div><b>${P(s.net)}</b>Net payments</div><div><b>${s.out} of ${s.cars}</b>Cars on the road</div><div><b>${s.overdue}</b>Overdue returns</div><div><b>${s.waiting}</b>Pickups waiting</div><div><b>${s.maint}</b>In maintenance</div><div><b>${s.refunds}</b>Refunds to send</div></div>
    <h2>Rental value by branch</h2>${s.branches.map(b => `<div class="bar"><span>${esc(b.branch)}</span><i style="width:${(b.value / mx) * 55}%;min-width:4px"></i><span>${P(b.value)}</span></div>`).join('')}`;
}
async function bookings() {
  const l = await api('admin_bookings'), img = (b, k, t) => `<a href="${API}?r=admin_file&id=${b.id}&kind=${k}" target="_blank" rel="noopener">${t}</a>`;
  view.innerHTML = `<h1 style="font-size:2.2rem">Bookings</h1><div class="scroll"><table class="tbl"><thead><tr><th>Ref</th><th>Driver</th><th>Licence check</th><th>Car and dates</th><th>Paid</th><th>Status</th><th></th></tr></thead><tbody>${l.map(b => {
    const st = +b.late ? 'overdue' : b.status, ok = +b.verified === 1;
    return `<tr><td>${esc(b.ref)}</td><td>${b.customer_id ? `<a href="#/customers/${b.customer_id}">${esc(b.name)}</a>` : esc(b.name)}<br><small>${esc(b.phone)}<br>${esc(b.license)} · expires ${esc(b.license_expiry || '?')}</small>${b.flag ? `<br><span class="tag s-overdue">${esc(b.flag)}</span>` : ''}</td>
    <td>${b.license_photo ? img(b, 'license', 'View licence photo') : '<small>no photo on file</small>'}${b.selfie_photo ? '<br>' + img(b, 'selfie', 'View selfie') : ''}<br>
      ${ok ? `<span class="tag s-returned">verified by ${esc(b.verified_by)}</span>` : b.status === 'reserved' ? `<span class="tag s-picked">not verified</span><br><button class="sm" data-act="verify" data-id="${b.id}">Mark verified</button>` : ''}
      ${b.status === 'reserved' ? `<button class="sm red" data-act="block" data-id="${b.id}">Block licence</button>` : ''}</td>
    <td>${esc(b.car)}<br><small>${esc(b.date_from)} to ${esc(b.date_to)}</small></td><td>${P(b.paid)}${+b.fee ? `<br><small>late fee ${P(b.fee)}</small>` : ''}</td>
    <td><span class="tag s-${st}">${+b.late ? 'overdue ' + b.late + 'd' : st}</span></td>
    <td>${b.status === 'reserved' ? `<button class="sm" data-act="status" data-id="${b.id}" ${ok ? '' : 'disabled title="Verify the licence first"'}>Hand over keys</button>` : b.status === 'picked' ? `<button class="sm dark" data-act="status" data-ret="1" data-id="${b.id}">Check in return</button>` : ''} <a class="btn sm" href="invoice.html?id=${b.id}" target="_blank" rel="noopener">Invoice</a></td></tr>`; }).join('') || '<tr><td colspan="7">No bookings yet. They appear here as customers book.</td></tr>'}</tbody></table></div>
    <p><small>Licence photos are deleted automatically when a car is returned or a booking is cancelled.</small></p>`;
  view.onclick = async e => {
    const b = e.target.closest('button[data-act]'); if (!b) return; const id = +b.dataset.id, a = b.dataset.act;
    try {
      if (a === 'status') { let km; if (b.dataset.ret) { km = prompt('Odometer reading at return (km)?'); if (km === null) return; } await api('admin_status', { body: { id, km } }); }
      else if (a === 'verify') { if (!confirm('Confirm the photo is clear, matches the renter, and the licence has not expired?')) return; await api('admin_verify', { body: { id } }); }
      else if (a === 'block') { const reason = prompt('Why is this licence being blocked?'); if (reason === null) return; await api('admin_block', { body: { id, reason } }); }
      bookings();
    } catch (x) { alert(x.message); }
  };
}
async function licences() {
  const l = await api('admin_blocked');
  view.innerHTML = `<h1 style="font-size:2.2rem">Blocked licences</h1><form class="addcar" id="bf"><div><label>Licence number<input name="license" required placeholder="Licence number"></label></div><div><label>Reason<input name="reason" required maxlength="200"></label></div><button>Block licence</button></form>
    <div class="scroll"><table class="tbl"><thead><tr><th>Licence</th><th>Reason</th><th>Added</th><th></th></tr></thead><tbody>${l.map(x => `<tr><td>${esc(x.license)}</td><td>${esc(x.reason)}</td><td>${esc(x.created_at)}</td><td><button class="sm ghost" data-un="${x.id}">Unblock</button></td></tr>`).join('') || '<tr><td colspan="4">No blocked licences.</td></tr>'}</tbody></table></div>
    <p><small>Anyone booking with a blocked licence number is turned away.</small></p>`;
  $('#bf').onsubmit = async e => { e.preventDefault(); try { await api('admin_block_add', { body: Object.fromEntries(new FormData(e.target)) }); licences(); } catch (x) { alert(x.message); } };
  view.querySelectorAll('button[data-un]').forEach(b => b.onclick = async () => { await api('admin_unblock', { body: { id: +b.dataset.un } }); licences(); });
}let editId = null, showRetired = false, photoFor = 0;
async function fleet() {
  const all = await api('admin_cars'), l = all.filter(c => showRetired || c.status !== 'retired'), T = ['Sedan', 'SUV', 'MPV', 'Van', 'Pickup'];
  const sel = (id, o, v) => `<select id="${id}">${o.map(x => `<option ${x === v ? 'selected' : ''}>${x}</option>`).join('')}</select>`;
  const tag = c => c.status === 'retired' ? '<span class="tag s-cancelled">retired</span>' : c.status === 'maint' ? '<span class="tag s-picked">out of service</span>' : +c.in_shop ? '<span class="tag s-picked">in the shop</span>' : '<span class="tag s-returned">available</span>';
  const row = c => c.id === editId
    ? `<tr><td><input id="en" value="${esc(c.name)}" maxlength="80"><input id="ep" value="${esc(c.plate || '')}" maxlength="12" placeholder="Plate, e.g. ABC 1234" style="margin-top:4px"></td><td>${sel('et', T, c.type)}</td><td><input id="es" type="number" value="${c.seats}" min="2" max="20" style="width:70px"></td><td>${sel('eb', BRANCHES, c.branch)}</td><td><input id="er" type="number" value="${c.rate}" min="500" style="width:100px"></td><td><input id="em" type="number" value="${c.mileage}" min="0" style="width:110px"></td><td>${tag(c)}</td><td><button class="sm" data-act="save" data-id="${c.id}">Save</button> <button class="sm ghost" data-act="cancel">Cancel</button></td></tr>`
    : `<tr><td><div class="vt">${c.photo ? `<img src="${ROOT}uploads/cars/${esc(c.photo)}" alt="">` : '<span class="noimg">no photo</span>'}<div><b>${esc(c.name)}</b><br><small>${esc(c.plate || 'no plate yet')}</small></div></div></td><td>${esc(c.type)}</td><td>${c.seats}</td><td>${esc(c.branch)}</td><td>${P(c.rate)}</td><td>${Number(c.mileage).toLocaleString()} km</td>
      <td>${tag(c)}${c.next_maint ? `<br><small>maintenance from ${esc(c.next_maint)}</small>` : ''}${+c.active ? `<br><small>${c.active} current or upcoming booking(s)</small>` : ''}</td><td>
      <button class="sm ghost" data-act="edit" data-id="${c.id}">Edit</button> <button class="sm ghost" data-act="photo" data-id="${c.id}">${c.photo ? 'Change photo' : 'Add photo'}</button>${c.photo ? ` <button class="sm ghost" data-act="unphoto" data-id="${c.id}">Remove photo</button>` : ''}
      ${c.status === 'retired' ? `<button class="sm ghost" data-act="restore" data-id="${c.id}">Restore</button>` : `<button class="sm ghost" data-act="toggle" data-id="${c.id}" data-active="${c.active}" data-st="${c.status}">${c.status === 'ok' ? 'Take out of service' : 'Back in service'}</button> <button class="sm ghost" data-act="retire" data-id="${c.id}">Retire</button>`}
      ${+c.history === 0 && !c.next_maint ? `<button class="sm red" data-act="del" data-id="${c.id}">Delete</button>` : ''}</td></tr>`;
  view.innerHTML = `<h1 style="font-size:2.2rem">Fleet</h1><form class="addcar" id="af"><div style="flex:2 1 160px"><label>Name<input name="name" required></label></div><div><label>Plate number<input name="plate" required maxlength="12" placeholder="ABC 1234"></label></div><div><label>Type<select name="type">${T.map(t => `<option>${t}</option>`).join('')}</select></label></div>
    <div><label>Seats<input name="seats" type="number" value="5" min="2" max="20"></label></div><div><label>Mileage (km)<input name="mileage" type="number" min="0" value="0"></label></div><div><label>Rate per day<input name="rate" type="number" min="500" required></label></div><div><label>Branch<select name="branch">${BRANCHES.map(b => `<option>${b}</option>`).join('')}</select></label></div><button>Add vehicle</button></form>
    <input type="file" id="pf" accept="image/jpeg,image/png" hidden>
    <label style="font-weight:400;margin-bottom:8px"><input type="checkbox" id="sr" style="width:auto" ${showRetired ? 'checked' : ''}> Show retired vehicles</label>
    <div class="scroll"><table class="tbl"><thead><tr><th>Vehicle</th><th>Type</th><th>Seats</th><th>Branch</th><th>Rate per day</th><th>Mileage</th><th>Status</th><th></th></tr></thead><tbody>${l.map(row).join('') || '<tr><td colspan="8">No vehicles.</td></tr>'}</tbody></table></div>
    <p><small>Photos appear on the customer site instead of the drawing. Mileage updates when you check a car in. Retire hides a car but keeps its history. Delete is only offered for cars with no bookings or maintenance records.</small></p>`;
  $('#af').onsubmit = async e => { e.preventDefault(); try { await api('admin_car_add', { body: Object.fromEntries(new FormData(e.target)) }); fleet(); } catch (x) { alert(x.message); } };
  $('#sr').onchange = e => { showRetired = e.target.checked; fleet(); };
  $('#pf').onchange = async e => {
    const file = e.target.files[0]; if (!file) return; const fd = new FormData(); fd.append('id', photoFor); fd.append('photo', await shrink(file), 'car.jpg');
    try { await api('admin_car_photo', { body: fd }); } catch (x) { alert(x.message); } fleet();
  };
  view.onclick = async e => {
    const b = e.target.closest('button[data-act]'); if (!b) return; const id = +b.dataset.id, a = b.dataset.act, v = i => $(i).value;
    if (a === 'photo') { photoFor = id; $('#pf').value = ''; $('#pf').click(); return; }
    try {
      if (a === 'edit') editId = id;
      else if (a === 'cancel') editId = null;
      else if (a === 'save') { await api('admin_car_edit', { body: { id, name: v('#en'), plate: v('#ep'), type: v('#et'), seats: v('#es'), rate: v('#er'), branch: v('#eb'), mileage: v('#em') } }); editId = null; }
      else if (a === 'toggle') { if (b.dataset.st === 'ok' && +b.dataset.active && !confirm('This car has upcoming bookings. Take it out of service anyway?')) return; await api('admin_car_toggle', { body: { id } }); }
      else if (a === 'unphoto') await api('admin_car_photo_remove', { body: { id } });
      else if (a === 'retire') { if (!confirm('Retire this vehicle? Customers will no longer see it.')) return; await api('admin_car_retire', { body: { id } }); }
      else if (a === 'restore') await api('admin_car_restore', { body: { id } });
      else if (a === 'del') { if (!confirm('Delete this vehicle permanently? This cannot be undone.')) return; await api('admin_car_delete', { body: { id } }); }
      fleet();
    } catch (x) { alert(x.message); }
  };
}
async function maintenance() {
  const [m, cars] = await Promise.all([api('admin_maint'), api('admin_cars')]), K = ['Scheduled service', 'Repair', 'Damage repair', 'Inspection'], t0 = today();
  const st = x => x.status === 'done' ? '<span class="tag s-returned">done</span>' : x.status === 'cancelled' ? '<span class="tag s-cancelled">cancelled</span>' : x.date_from <= t0 && t0 <= x.date_to ? '<span class="tag s-picked">in progress</span>' : '<span class="tag s-reserved">scheduled</span>';
  view.innerHTML = `<h1 style="font-size:2.2rem">Maintenance</h1><form class="addcar" id="mf"><div style="flex:2 1 200px"><label>Vehicle<select name="car_id">${cars.filter(c => c.status !== 'retired').map(c => `<option value="${c.id}">${esc(c.name)} (${esc(c.plate || 'no plate')})</option>`).join('')}</select></label></div>
    <div><label>Work<select name="kind">${K.map(k => `<option>${k}</option>`).join('')}</select></label></div><div><label>From<input name="date_from" type="date" min="${t0}" required></label></div><div><label>Until (inclusive)<input name="date_to" type="date" min="${t0}" required></label></div>
    <div><label>Cost (₱)<input name="cost" type="number" min="0" value="0"></label></div><div style="flex:2 1 220px"><label>Notes<input name="notes" maxlength="300"></label></div><button>Schedule</button></form>
    <div class="scroll"><table class="tbl"><thead><tr><th>Vehicle</th><th>Work</th><th>Dates</th><th>Notes</th><th>Cost</th><th>Status</th><th></th></tr></thead><tbody>${m.map(x => `<tr><td>${esc(x.car)}<br><small>${esc(x.plate || '')}</small></td><td>${esc(x.kind)}</td><td>${esc(x.date_from)} to ${esc(x.date_to)}</td><td>${esc(x.notes)}</td><td>${P(x.cost)}</td><td>${st(x)}</td>
      <td>${x.status === 'scheduled' ? `<button class="sm" data-m="done" data-id="${x.id}">Mark done</button> <button class="sm ghost" data-m="cancelled" data-id="${x.id}">Cancel</button>` : ''}</td></tr>`).join('') || '<tr><td colspan="7">Nothing scheduled yet.</td></tr>'}</tbody></table></div>
    <p><small>Scheduled cars cannot be booked for those dates, and you cannot schedule work over an existing booking.</small></p>`;
  $('#mf').onsubmit = async e => { e.preventDefault(); try { await api('admin_maint_add', { body: Object.fromEntries(new FormData(e.target)) }); maintenance(); } catch (x) { alert(x.message); } };
  view.onclick = async e => { const b = e.target.closest('button[data-m]'); if (!b) return; try { await api('admin_maint_status', { body: { id: +b.dataset.id, status: b.dataset.m } }); maintenance(); } catch (x) { alert(x.message); } };
}


let custQ = '';
async function customers(id) { return id ? customerPage(+id) : customerList(); }
async function customerList() {
  const l = await api('admin_customers', { q: { q: custQ } }), t0 = today(), soon = add(t0, 30);
  const exp = c => !c.license_expiry ? '' : c.license_expiry < t0 ? '<span class="tag s-overdue">expired</span>' : c.license_expiry <= soon ? '<span class="tag s-picked">expires soon</span>' : '';
  view.innerHTML = `<h1 style="font-size:2.2rem">Customers</h1><form class="find" id="cs" style="max-width:620px;box-shadow:none"><div><label for="cq">Search by name, email, phone or licence</label><input id="cq" value="${esc(custQ)}"></div><button style="align-self:end">Search</button></form>
    <div class="scroll"><table class="tbl"><thead><tr><th>Customer</th><th>Phone</th><th>Licence</th><th>Rentals</th><th>Spent</th><th>Last rental</th></tr></thead><tbody>${l.map(c => `<tr><td><a href="#/customers/${c.id}"><b>${esc(c.name)}</b></a><br><small>${esc(c.email)}</small></td><td>${esc(c.phone)}</td>
      <td>${esc(c.license)}<br><small>expires ${esc(c.license_expiry || 'not recorded')}</small> ${exp(c)}${+c.blocked ? ' <span class="tag s-overdue">blocked</span>' : ''}${+c.dup ? ' <span class="tag s-picked">shared licence</span>' : ''}</td><td>${c.rentals}</td><td>${P(c.spent)}</td><td>${esc(c.last_rental || '')}</td></tr>`).join('') || '<tr><td colspan="6">No customers found.</td></tr>'}</tbody></table></div>
    <p><small>Customers are created automatically the first time someone books. Open one to edit their details or see their rental history.</small></p>`;
  $('#cs').onsubmit = e => { e.preventDefault(); custQ = $('#cq').value.trim(); customerList(); };
}
async function customerPage(id) {
  const d = await api('admin_customer', { q: { id } }), c = d.customer, erased = c.license.startsWith('ERASED-');
  const f = (n, label, type = 'text', extra = '') => `<label>${label}<input name="${n}" type="${type}" value="${esc(c[n] || '')}" ${extra}></label>`;
  view.innerHTML = `<p><a href="#/customers">Back to customers</a></p><h1 style="font-size:2.2rem">${esc(c.name)}</h1>
    ${d.blocked ? '<p><span class="tag s-overdue">Licence blocked: bookings are refused</span></p>' : ''}${+d.dup ? `<p><span class="tag s-picked">The same licence number is on ${d.dup} other customer record(s)</span></p>` : ''}
    <div class="two"><form class="panel" id="cf"><h2>Details</h2>${f('name', 'Full name', 'text', 'required maxlength="100"')}${f('email', 'Email', 'email', 'required maxlength="120"')}${f('phone', 'Phone', 'text', 'required maxlength="30"')}${f('address', 'Address', 'text', 'maxlength="200"')}${f('birth_date', 'Date of birth', 'date')}
      ${f('license', 'Driver’s licence number', 'text', 'required maxlength="30"')}${f('license_expiry', 'Licence expiry', 'date')}${f('emergency_contact', 'Emergency contact (name and number)', 'text', 'maxlength="120"')}
      <label>Staff notes (never shown to the customer)<textarea name="notes" maxlength="500">${esc(c.notes || '')}</textarea></label>
      <p class="err" id="ce" role="alert"></p><p id="cm" role="status" style="color:#145a37;font-weight:600"></p>
      <div style="display:flex;gap:8px;flex-wrap:wrap"><button ${erased ? 'disabled' : ''}>Save changes</button><button type="button" class="ghost" data-c="${d.blocked ? 'unblock' : 'block'}" ${erased ? 'disabled' : ''}>${d.blocked ? 'Unblock licence' : 'Block licence'}</button><button type="button" class="red" data-c="erase" ${erased ? 'disabled' : ''}>Erase personal data</button></div>
      <p><small>Saving a new email also updates it on their bookings. Changing the licence number or expiry on an upcoming booking means staff must verify it again.</small></p></form>
    <div><h2>Rental history</h2><div class="scroll"><table class="tbl"><thead><tr><th>Ref</th><th>Car</th><th>Dates</th><th>Total</th><th>Status</th></tr></thead><tbody>${d.bookings.map(b => `<tr><td>${esc(b.ref)}</td><td>${esc(b.car)}</td><td>${esc(b.date_from)} to ${esc(b.date_to)}</td><td>${P(+b.total + +b.fee)}</td><td><span class="tag s-${b.status}">${b.status}</span></td></tr>`).join('') || '<tr><td colspan="5">No bookings yet.</td></tr>'}</tbody></table></div></div></div>`;
  $('#cf').onsubmit = async e => {
    e.preventDefault(); $('#ce').textContent = '';
    try { await api('admin_customer_save', { body: { id, ...Object.fromEntries(new FormData(e.target)) } }); await customerPage(id); $('#cm').textContent = 'Saved.'; }
    catch (x) { $('#ce').textContent = x.message; }
  };
  $('#cf').onclick = async e => {
    const b = e.target.closest('button[data-c]'); if (!b) return; const a = b.dataset.c;
    try {
      if (a === 'block') { const reason = prompt('Why is this licence being blocked? Upcoming bookings will be cancelled and refunded.'); if (reason === null) return; await api('admin_customer_block', { body: { id, reason } }); }
      else if (a === 'unblock') { if (!confirm('Allow this licence to book again?')) return; await api('admin_customer_unblock', { body: { id } }); }
      else if (a === 'erase') { if (!confirm('Erase this customer’s personal data? Name, contact details, licence and photos are removed for good. Payment records stay, without names.')) return; await api('admin_customer_erase', { body: { id } }); location.hash = '#/customers'; return; }
      customerPage(id);
    } catch (x) { alert(x.message); }
  };
}
addEventListener('hashchange', render); render();
