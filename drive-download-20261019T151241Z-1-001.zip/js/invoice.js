const money = n => (n < 0 ? '−' : '') + '₱' + Math.abs(Math.round(n)).toLocaleString();
const admin = location.pathname.includes('/admin/'), el = $('#inv');
const head = (d, right) => { const b = d.business; return `<header class="inv-h"><div><h1>${esc(b.registered_name || b.name)}</h1><p>${esc(b.address)}${b.phone ? '<br>' + esc(b.phone) : ''}${b.email ? '<br>' + esc(b.email) : ''}${b.tin ? '<br>TIN: ' + esc(b.tin) + (b.branch_code ? ' · Branch ' + esc(b.branch_code) : '') : ''}</p></div><div class="r">${right}</div></header>${d.draft ? '<p class="draft">Not an official tax document. Layout and numbering are placeholders until confirmed by your accountant.</p>' : ''}`; };
const rlink = id => { const q = new URLSearchParams(location.search); q.set('pid', id); return '?' + q; };
function invoice(d) {
  const x = (i, a) => admin && i ? ` <button class="sm ghost noprint" data-${a}="${i}" title="Remove">×</button>` : '', tone = d.state === 'Paid in full' ? 's-returned' : d.state === 'Cancelled' ? 's-cancelled' : 's-overdue', t = d.tax;
  const pay = p => `<tr><td>${esc(p.t)}</td><td>${p.kind === 'refund' ? 'Refund' : 'Payment'} · ${esc(p.method)}${p.ref ? ' · ref ' + esc(p.ref) : ''}${p.note ? ' · ' + esc(p.note) : ''}${p.status === 'pending' ? ' <span class="tag s-picked">to be sent</span>' : ''}${p.receipt ? `<br><small><a href="${rlink(p.id)}">${esc(d.receipt_title)} ${esc(p.receipt)}</a></small>` : ''}</td><td class="r">${p.kind === 'refund' ? '−' : ''}${money(p.a).replace('−', '')}</td>
    ${admin ? `<td class="noprint">${p.kind === 'refund' && p.status === 'pending' ? `<button class="sm" data-pay="complete" data-id="${p.id}">Mark sent</button> ` : ''}${p.gateway ? '' : `<button class="sm ghost" data-pay="void" data-id="${p.id}">Void</button>`}</td>` : ''}</tr>`;
  return `<article class="inv">${head(d, `<h2>${esc(d.title)}</h2><b>${esc(d.no || '(not issued: booking cancelled)')}</b><br>Issued ${esc(d.issued)}<br><span class="tag ${tone}">${esc(d.state)}</span>`)}
    <div class="inv-two"><div><small>Billed to</small><br><b>${esc(d.customer.name)}</b><br>${esc(d.customer.email)}<br>${esc(d.customer.phone)}</div><div><small>Booking</small><br><b>${esc(d.booking.ref)}</b><br>${esc(d.booking.car)}${admin && d.booking.plate ? ' (' + esc(d.booking.plate) + ')' : ''}<br>${esc(d.booking.from)} to ${esc(d.booking.to)}</div></div>
    <table class="tbl inv-t"><thead><tr><th>Description</th><th class="r">Amount</th></tr></thead><tbody>${d.lines.map(l => `<tr><td>${esc(l.d)}${x(l.id, 'del')}</td><td class="r">${money(l.a)}</td></tr>`).join('') || '<tr><td colspan="2">Cancelled: nothing is charged.</td></tr>'}
    <tr class="tot"><td>Total charges</td><td class="r">${money(d.total)}</td></tr>${t.mode === 'inclusive' ? `<tr><td><small>VATable amount</small></td><td class="r"><small>${money(d.total - t.vat)}</small></td></tr><tr><td><small>${esc(t.label)} at ${Math.round(t.rate * 100)}% (included above)</small></td><td class="r"><small>${money(t.vat)}</small></td></tr>` : ''}</tbody></table>
    <table class="tbl inv-t"><thead><tr><th>Date</th><th>Payments and refunds</th><th class="r">Amount</th>${admin ? '<th class="noprint"></th>' : ''}</tr></thead><tbody>${d.payments.map(pay).join('') || `<tr><td colspan="${admin ? 4 : 3}">No payments yet.</td></tr>`}</tbody></table>
    <div class="inv-sum"><div><span>Payments counted toward charges</span><b>${money(d.received)}</b></div>${d.deposit_held ? `<div><span>Security deposit held (returned after check-in)</span><b>${money(d.deposit_held)}</b></div>` : ''}<div class="due"><span>${d.balance < 0 ? 'Overpaid (owed back to customer)' : 'Balance due'}</span><b>${money(Math.abs(d.balance))}</b></div></div>
    ${d.footer ? `<p class="r"><small>${esc(d.footer)}</small></p>` : ''}<p class="noprint"><button onclick="print()">Print or save as PDF</button></p></article>
    ${admin ? `<section class="noprint panel" style="margin-top:20px"><h3>Billing actions</h3>
      <form class="addcar" id="ac"><div style="flex:2 1 200px"><label>Extra charge<input name="description" required maxlength="120" placeholder="e.g. Cleaning fee, traffic fine"></label></div><div><label>Amount (₱)<input name="amount" type="number" min="1" required></label></div><button>Add charge</button></form>
      <form class="addcar" id="ap"><div><label>Entry<select name="kind"><option value="payment">Payment received</option><option value="refund">Refund sent</option></select></label></div><div><label>Method<select name="method">${d.methods.map(m => `<option>${esc(m)}</option>`).join('')}</select></label></div><div><label>Amount (₱)<input name="amount" type="number" min="1" required></label></div><div><label>Reference no.<input name="reference" maxlength="80" placeholder="GCash or bank ref"></label></div><button class="dark">Record</button></form>
      <small>Extra charges added before check-in come out of the deposit refund. Pending refunds are money still to be sent: mark them sent once done.</small></section>` : ''}`;
}
function receipt(d, p) {
  return `<article class="inv">${head(d, `<h2>${esc(d.receipt_title)}</h2><b>${esc(p.receipt)}</b><br>${esc(p.t)}`)}
    <p style="margin:22px 0">Received from <b>${esc(d.customer.name)}</b> the amount of <b>${money(p.a)}</b> by ${esc(p.method)}${p.ref ? ' (ref ' + esc(p.ref) + ')' : ''}, for booking <b>${esc(d.booking.ref)}</b>: ${esc(d.booking.car)}, ${esc(d.booking.from)} to ${esc(d.booking.to)}.</p>
    ${d.footer ? `<p><small>${esc(d.footer)}</small></p>` : ''}<p class="noprint"><button onclick="print()">Print or save as PDF</button></p></article>`;
}
const load = async () => {
  try {
    const qs = new URLSearchParams(location.search); let d;
    if (admin) d = await api('admin_invoice', { q: { id: qs.get('id') } });
    else if (qs.get('t')) d = await api('invoice', { q: { t: qs.get('t') } });
    else { const k = JSON.parse(sessionStorage.getItem('rk_inv') || 'null'); if (!k) { el.innerHTML = '<p>Open an invoice from <a href="index.html#/mine">My bookings</a> or from the link in your email.</p>'; return; } d = await api('invoice', { q: k }); }
    const p = qs.get('pid') && d.payments.find(x => x.id === +qs.get('pid') && x.receipt);
    document.title = p ? p.receipt : (d.no || d.title); el.innerHTML = p ? receipt(d, p) : invoice(d);
    if (!admin || p) return;
    const post = async (r, body) => { try { await api(r, { body }); load(); } catch (x) { alert(x.message); } };
    el.onclick = e => {
      const del = e.target.closest('button[data-del]'), pay = e.target.closest('button[data-pay]');
      if (del && confirm('Remove this charge?')) post('admin_item_delete', { id: +del.dataset.del });
      if (pay && pay.dataset.pay === 'void' && confirm('Void this entry? It will no longer count.')) post('admin_payment_update', { id: +pay.dataset.id, action: 'void' });
      if (pay && pay.dataset.pay === 'complete') { const method = prompt('How was the refund sent? (' + d.methods.join(', ') + ')', d.methods[0]); if (method === null) return; const reference = prompt('Reference number (optional)') || ''; post('admin_payment_update', { id: +pay.dataset.id, action: 'complete', method, reference }); }
    };
    $('#ac').onsubmit = e => { e.preventDefault(); const f = Object.fromEntries(new FormData(e.target)); post('admin_item_add', { booking_id: d.booking.id, description: f.description, amount: f.amount }); };
    $('#ap').onsubmit = e => { e.preventDefault(); post('admin_payment_add', { booking_id: d.booking.id, ...Object.fromEntries(new FormData(e.target)) }); };
  } catch (e) { if (e.status === 401) location.href = 'login.html'; else el.innerHTML = `<p class="err">${esc(e.message)}</p>`; }
};
load();
