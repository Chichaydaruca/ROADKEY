const API = location.pathname.includes('/admin/') ? '../api/index.php' : 'api/index.php';
const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const P = n => '₱' + Math.round(n).toLocaleString();
const BRANCHES = ['Manila', 'Cebu', 'Davao'];
const fmt = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
const today = () => fmt(new Date());
const add = (s, n) => { const [y, m, d] = s.split('-').map(Number); return fmt(new Date(y, m - 1, d + n)); };
async function api(r, { q, body } = {}) {
  const res = await fetch(API + '?r=' + r + (q ? '&' + new URLSearchParams(q) : ''), {
    method: body ? 'POST' : 'GET', headers: body instanceof FormData ? { 'X-Requested-With': 'roadkey' } : { 'Content-Type': 'application/json' }, body: body instanceof FormData ? body : body ? JSON.stringify(body) : undefined, credentials: 'same-origin' });
  const j = await res.json().catch(() => ({}));
  if (!res.ok) { const e = new Error(j.error || 'Something went wrong.'); e.status = res.status; throw e; }
  return j;
}
const COLORS = ['#ffc20e', '#f0503c', '#ffffff', '#4f7cff', '#3ec58f', '#c3cad6'];
function carArt(type, id) {
  const c = COLORS[id % 6], s = 'stroke="#14213d" stroke-width="3" stroke-linejoin="round"', w = '#d4ecfb', suv = type === 'SUV' || type === 'MPV';
  const body = type === 'Van'
    ? `<rect x="14" y="30" width="212" height="54" rx="14" fill="${c}" ${s}/><rect x="150" y="40" width="58" height="26" rx="5" fill="${w}" ${s}/><rect x="36" y="40" width="34" height="26" rx="4" fill="${w}" ${s}/><rect x="78" y="40" width="34" height="26" rx="4" fill="${w}" ${s}/>`
    : (type === 'Pickup' ? `<rect x="140" y="44" width="86" height="14" rx="3" fill="${c}" ${s}/>` : '') +
      `<path d="${suv ? 'M44 58L56 28H182L200 58Z' : type === 'Pickup' ? 'M40 58L58 30H116L136 58Z' : 'M56 58L84 32H152L184 58Z'}" fill="${c}" ${s}/>` +
      `<path d="${suv ? 'M60 55L66 35H112V55ZM118 55V35H174L188 55Z' : type === 'Pickup' ? 'M63 55L73 37H108L122 55Z' : 'M72 55L90 38H116V55ZM122 55V38H148L170 55Z'}" fill="${w}" ${s}/><rect x="14" y="56" width="212" height="28" rx="10" fill="${c}" ${s}/>`;
  return `<svg viewBox="0 0 240 110" role="img" aria-label="${esc(type)}"><ellipse cx="120" cy="100" rx="100" ry="6" fill="#14213d" opacity=".15"/>${body}` +
    [64, 180].map(x => `<circle cx="${x}" cy="86" r="16" fill="#14213d"/><circle cx="${x}" cy="86" r="6" fill="#d4ecfb"/>`).join('') + '</svg>';
}
const ROOT = API.replace('api/index.php', '');
async function shrink(file) {   // phone photos are huge: resize to max 1600px JPEG before upload
  const bmp = await createImageBitmap(file).catch(() => null); if (!bmp) return file;
  const k = Math.min(1, 1600 / Math.max(bmp.width, bmp.height)), c = document.createElement('canvas');
  c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k); c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
  return new Promise(r => c.toBlob(b => r(b || file), 'image/jpeg', .82));
}
function carPic(c) { return c.photo ? `<img src="${ROOT}uploads/cars/${esc(c.photo)}" alt="${esc(c.name)}" loading="lazy">` : carArt(c.type, c.id); }
