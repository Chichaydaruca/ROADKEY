const S = { from: add(today(), 1), to: add(today(), 3), branch: '' }, app = $('#app');
async function route() {
  const h = location.hash.slice(2).split('/');
  try { if (h[0] === 'car') await carView(+h[1]); else if (h[0] === 'mine') mineView(); else if (h[0] === 'paid') await paidView(h[1]); else await homeView(); }
  catch (e) { app.innerHTML = `<p class="err">${esc(e.message)}</p>`; }
  scrollTo(0, 0);
}
async function homeView() {
  app.innerHTML = `<section class="hero"><div><h1>Your ride is waiting in Manila, Cebu or Davao.</h1><p>Pick your dates, see the real price, and pay a refundable deposit to hold the car. Weekends cost 15% more, and a week or longer takes 10% off.</p>
    <div class="find"><div><label for="f">Pickup</label><input id="f" type="date" min="${today()}" value="${S.from}"></div><div><label for="t">Return</label><input id="t" type="date" value="${S.to}"></div>
    <div><label for="b">Branch</label><select id="b"><option value="">Any</option>${BRANCHES.map(b => `<option ${S.branch === b ? 'selected' : ''}>${b}</option>`).join('')}</select></div></div></div>
    <div class="stage">${carArt('SUV', 0)}</div></section><h2 id="count"></h2><div class="grid" id="list"></div>`;
  const load = async () => {
    $('#t').min = add(S.from, 1);
    try {
      const cars = await api('cars', { q: { from: S.from, to: S.to, branch: S.branch } });
      $('#count').textContent = `${cars.length} ${cars.length === 1 ? 'car' : 'cars'} free on your dates`;
      $('#list').innerHTML = cars.map(c => `<article class="car"><div class="art${c.photo ? ' photo' : ''}">${carPic(c)}</div><div class="body"><h3>${esc(c.name)}</h3><span class="spec">${esc(c.type)}, ${c.seats} seats, pickup in ${esc(c.branch)}</span>
        <div class="price">${P(c.quote.total)} <small>for ${c.quote.days} day${c.quote.days > 1 ? 's' : ''}</small></div><a class="btn" style="margin-top:auto" href="#/car/${c.id}">Book this car</a></div></article>`).join('') || '<p>Nothing is free on those dates. Try different days or another branch.</p>';
    } catch (e) { $('#count').textContent = ''; $('#list').innerHTML = `<p class="err">${esc(e.message)}</p>`; }
  };
  $('#f').onchange = e => { S.from = e.target.value; if (S.to <= S.from) { S.to = add(S.from, 1); $('#t').value = S.to; } load(); };
  $('#t').onchange = e => { S.to = e.target.value; load(); };
  $('#b').onchange = e => { S.branch = e.target.value; load(); };
  load();
}
async function carView(id) {
  const car = await api('car', { q: { id } });
  app.innerHTML = `<div class="two"><div><div class="big${car.photo ? ' photo' : ''}">${carPic(car)}</div><h1 style="margin-top:20px">${esc(car.name)}</h1><p class="spec">${esc(car.type)}, ${car.seats} seats, pickup in ${esc(car.branch)}. ${P(car.rate)} per day.</p></div>
    <form class="panel" id="bf"><h2>Book this car</h2><label>Pickup<input name="from" type="date" min="${today()}" value="${S.from}" required></label><label>Return<input name="to" type="date" value="${S.to}" required></label>
    <label>Full name<input name="name" required maxlength="100"></label><label>Email<input name="email" type="email" required></label><label>Phone<input name="phone" required maxlength="30"></label><label>Driver’s licence number<input name="license" required maxlength="30" placeholder="As printed on your licence" title="Letters and numbers, as printed on your licence"></label>
    <label>Licence expiry date<input name="license_expiry" type="date" min="${today()}" required></label>
    <label>Photo of your licence (front) <small>JPG or PNG; large photos are shrunk for you</small><input name="license_photo" type="file" accept="image/jpeg,image/png" required></label>
    <label>Selfie holding your licence <small>(optional, speeds up pickup)</small><input name="selfie_photo" type="file" accept="image/jpeg,image/png" capture="user"></label>
    <label style="margin-top:14px;font-weight:400"><input name="consent" type="checkbox" required style="width:auto"> I agree my licence photo is kept only to verify me and is deleted after my rental.</label>
    <label style="margin-top:14px"><input name="pay_full" type="checkbox" style="width:auto"> Pay the whole rental now <small>(otherwise just the deposit)</small></label><p id="sum"></p><p class="err" id="err" role="alert"></p><button>Confirm booking</button></form></div>`;
  const f = $('#bf'), sum = async () => {
    S.from = f.from.value; S.to = f.to.value;
    try { const c = await api('car', { q: { id, from: S.from, to: S.to } }), q = c.quote;
      $('#sum').innerHTML = q ? `${q.days} day${q.days > 1 ? 's' : ''}${q.weekend ? `, ${q.weekend} at weekend rates` : ''}${q.discount ? ', 10% long-stay discount' : ''}<br><b>Rental ${P(q.total)}</b> plus a ${P(5000)} deposit you get back.` : 'Return must be after pickup.';
    } catch (e) { $('#sum').textContent = ''; }
  };
  f.from.onchange = f.to.onchange = sum; sum();
  f.onsubmit = async e => {
    e.preventDefault(); const b = f.querySelector('button'); b.disabled = true; $('#err').textContent = '';
    const d = new FormData(f); d.append('car_id', id); for (const k of ['license_photo', 'selfie_photo']) { const file = d.get(k); if (file && file.size) d.set(k, await shrink(file), k + '.jpg'); else d.delete(k); }
    try { const r = await api('book', { body: d });
      app.innerHTML = `<div class="panel" style="max-width:520px"><h1 style="font-size:2.2rem">You’re booked.</h1><p>Your reference is <b style="font-size:1.4rem">${esc(r.ref)}</b>. Keep it: you need it with your email to view or cancel the booking.</p><p>${r.checkout_url ? 'Taking you to the secure payment page…' : `Please pay <b>${P(r.due)}</b> at pickup. This includes the ${P(5000)} refundable deposit, and your car is held for you.`}</p><p>Staff will check your licence before pickup. Please bring the actual licence with you.</p><a class="btn" href="#/mine">View my booking</a></div>`;
      if (r.checkout_url) location.href = r.checkout_url;
    } catch (x) { $('#err').textContent = x.message; b.disabled = false; }
  };
}
function mineView() {
  app.innerHTML = `<h1 style="font-size:2.4rem">My bookings</h1><form class="find" id="lf" style="max-width:620px"><div><label for="e">Email</label><input id="e" type="email" required></div><div><label for="r">Reference</label><input id="r" required placeholder="BK1A2B3C"></div><button style="align-self:end">Find</button></form><div id="res"></div>`;
  const show = async () => {
    try { const l = await api('lookup', { q: { email: $('#e').value, ref: $('#r').value } });
      $('#res').innerHTML = l.map(b => `<div class="ticket"><b>${esc(b.ref)}</b> · ${esc(b.car)} · ${esc(b.date_from)} to ${esc(b.date_to)} <span class="tag s-${b.status}">${b.status}</span><br>${b.status === 'reserved' ? 'Licence: ' + (+b.verified ? 'verified' : 'waiting for staff check') + '<br>' : ''}Rental ${P(b.total)} · paid ${P(b.paid)} · refunded ${P(b.refunded)}${b.fee > 0 ? ` · late fee ${P(b.fee)}` : ''}
        <p style="margin:8px 0 0"><button class="sm ghost" id="iv">View invoice</button>${b.pay_online && b.status === 'reserved' && +b.paid < +b.due_now ? ' <button class="sm" id="pay">Pay now</button>' : ''}${b.status === 'reserved' ? ' <button class="sm red" id="cx">Cancel and refund</button>' : ''}</p></div>`).join('') || '<p>We found no booking with that email and reference.</p>';
      const pay = $('#pay'); if (pay) pay.onclick = async () => { try { location.href = (await api('pay_link', { body: { email: $('#e').value, ref: $('#r').value } })).url; } catch (e) { alert(e.message); } };
      const iv = $('#iv'); if (iv) iv.onclick = () => { sessionStorage.setItem('rk_inv', JSON.stringify({ email: $('#e').value, ref: $('#r').value })); location.href = 'invoice.html'; };
      const cx = $('#cx'); if (cx) cx.onclick = async () => { try { await api('cancel', { body: { email: $('#e').value, ref: $('#r').value } }); show(); } catch (e) { alert(e.message); } };
    } catch (e) { $('#res').innerHTML = `<p class="err">${esc(e.message)}</p>`; }
  };
  $('#lf').onsubmit = e => { e.preventDefault(); show(); };
}
async function paidView(t) {
  const box = h => app.innerHTML = `<div class="panel" style="max-width:520px">${h}</div>`; let tries = 0; box('<h2>Checking your payment…</h2>');
  const go = async () => {
    const r = await api('pay_verify', { q: { t } }), ok = r.paid >= r.due;
    if (ok || ++tries > 5) box(`<h1 style="font-size:2.2rem">${ok ? 'Payment received.' : 'Still processing.'}</h1><p>Booking <b>${esc(r.ref)}</b>. ${ok ? 'We have emailed your confirmation.' : 'If you paid, it can take a minute to show. Check My bookings shortly.'}</p><a class="btn" href="#/mine">My bookings</a>`);
    else setTimeout(go, 2500);
  };
  await go();
}
addEventListener('hashchange', route); route();
