-- Run once in phpMyAdmin (SQL tab) if you already imported an older database.sql.
USE roadkey;
ALTER TABLE bookings
  ADD COLUMN due_now INT NOT NULL DEFAULT 0 AFTER discount,
  ADD COLUMN gateway_ref VARCHAR(80) NULL AFTER due_now,
  ADD COLUMN hold_until DATETIME NULL AFTER gateway_ref;
CREATE TABLE IF NOT EXISTS payments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT NOT NULL,
  kind ENUM('payment','refund') NOT NULL,
  amount INT NOT NULL,
  method VARCHAR(30) NOT NULL,
  status ENUM('completed','pending','void') NOT NULL DEFAULT 'completed',
  reference VARCHAR(80) NULL,
  gateway_id VARCHAR(80) NULL UNIQUE,
  note VARCHAR(120) NOT NULL DEFAULT '',
  created_by VARCHAR(50) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
  INDEX (booking_id)
);
CREATE TABLE IF NOT EXISTS documents (
  id INT AUTO_INCREMENT PRIMARY KEY,
  doc_type VARCHAR(10) NOT NULL,
  seq INT NOT NULL,
  number VARCHAR(40) NOT NULL UNIQUE,
  booking_id INT NOT NULL,
  payment_id INT NOT NULL DEFAULT 0,
  issued_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (doc_type, seq),
  UNIQUE (booking_id, doc_type, payment_id),
  FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS doc_counters (
  doc_type VARCHAR(10) PRIMARY KEY,
  last_seq INT NOT NULL
);
-- Move existing payment records into the new ledger
INSERT INTO payments (booking_id, kind, amount, method, status, note, created_at)
  SELECT b.id, 'payment', b.paid - COALESCE((SELECT SUM(i.amount) FROM booking_items i WHERE i.booking_id = b.id AND i.kind = 'payment'), 0),
         'Recorded earlier', 'Recorded before the payment ledger existed', 'completed', b.created_at
  FROM bookings b WHERE b.paid - COALESCE((SELECT SUM(i.amount) FROM booking_items i WHERE i.booking_id = b.id AND i.kind = 'payment'), 0) > 0;
INSERT INTO payments (booking_id, kind, amount, method, status, note, created_at)
  SELECT booking_id, 'payment', amount, 'Cash', 'completed', description, created_at FROM booking_items WHERE kind = 'payment';
DELETE FROM booking_items WHERE kind = 'payment';
INSERT INTO payments (booking_id, kind, amount, method, status, note)
  SELECT id, 'refund', refunded, 'Recorded earlier', 'completed', 'Recorded before the payment ledger existed' FROM bookings WHERE refunded > 0;
