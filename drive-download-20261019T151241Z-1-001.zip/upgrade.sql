-- Run this in phpMyAdmin (SQL tab) ONLY if you already imported the older database.sql.
USE roadkey;
ALTER TABLE bookings
  ADD COLUMN license_expiry DATE NULL AFTER license,
  ADD COLUMN license_photo VARCHAR(60) NULL AFTER license_expiry,
  ADD COLUMN selfie_photo VARCHAR(60) NULL AFTER license_photo,
  ADD COLUMN verified TINYINT(1) NOT NULL DEFAULT 0 AFTER selfie_photo,
  ADD COLUMN verified_by VARCHAR(50) NULL AFTER verified,
  ADD COLUMN verified_at DATETIME NULL AFTER verified_by,
  ADD COLUMN flag VARCHAR(160) NULL AFTER verified_at,
  ADD INDEX (license);
CREATE TABLE IF NOT EXISTS blocked_licenses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  license VARCHAR(40) NOT NULL UNIQUE,
  reason VARCHAR(200) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
UPDATE bookings SET verified = 1 WHERE status <> 'reserved';
