# RoadKey Car Rental (HTML + CSS + JavaScript + PHP + MySQL) for XAMPP

1. Install XAMPP. In the XAMPP Control Panel, start **Apache** and **MySQL**.
2. Copy this whole folder to `C:\xampp\htdocs\roadkey` (Mac/Linux: `htdocs/roadkey`).
3. Open http://localhost/phpmyadmin, click **Import**, choose `database.sql`, click **Import**.
4. Open http://localhost/roadkey/setup.php, create your admin username and password, then **delete setup.php**.
5. Public site: http://localhost/roadkey/   Admin: http://localhost/roadkey/admin/login.html

The admin password is stored only as a hash in the `admins` table. DB settings are in api/config.php.

## Driver licence checks (added)
- New install: import `database.sql`. Already imported the old one? Run `upgrade.sql` in phpMyAdmin instead.
- Licence photos are saved in a `roadkey_private` folder next to `htdocs` (outside the website), and only signed-in staff can open them.
- Staff must click **Mark verified** before **Hand over keys** works (enforced on the server).
- Photos are deleted when a car is returned or a booking is cancelled.
- Licence numbers: any 5 to 20 letters and numbers are accepted (dashes and spaces ignored). To enforce a stricter format, set `license.pattern` in api/settings.php.

## Vehicle management (added)
Fleet tab: add, edit, send to maintenance, retire/restore, and delete (only for cars that never had a booking).
Existing database? Run `upgrade-vehicles.sql` in phpMyAdmin once.

## Vehicle details and maintenance scheduling (added)
- Existing database? Run `upgrade-details.sql` in phpMyAdmin, then open Fleet and enter each car's plate number.
- Car photos are stored in `uploads/cars/` (public, scripts disabled there) and replace the drawings on the customer site.
- Mileage is entered when a car is checked in; the Maintenance tab schedules work by date range and blocks bookings on those dates.

## Customers (added)
- Existing database? Run `upgrade-customers.sql` once in phpMyAdmin. It builds the customer list from your existing bookings.
- Admin > Customers: search, edit details (address, date of birth, emergency contact, staff notes), see rental history, block a licence, or erase personal data.
- Erasing keeps payment records but removes names, contact details, licence numbers and photos. A blocked licence stays on the blocklist; check with a lawyer how long you may keep it.

## Invoices (added)
- Existing database? Run `upgrade-billing.sql` once in phpMyAdmin.
- Edit `BUSINESS` (name, address, TIN) and `VAT_RATE` in api/config.php so invoices carry your details.
- Customers: My bookings > View invoice. Staff: Bookings > Invoice, where charges and counter payments can be recorded.
- Invoice numbers look like INV-2026-00012 (booking id). Ask your accountant whether you also need official receipts.

## Settings, tax placeholders, payments and email (added)
Everything your accountant has to confirm lives in **api/settings.php**, with ASK ACCOUNTANT comments:
VAT mode and rate, document titles and number formats, official receipts on/off, TIN and business name, and the "not an official tax document" notice.
- Existing database? Run `upgrade-payments.sql` once. It moves old payments into the new ledger.
- Payments: `manual` (staff record cash/GCash/etc. at the counter; the deposit must be recorded before keys are handed over) or `paymongo` (online checkout; put your test secret key in settings.php).
  Refunds are queued as "to be sent" and staff mark them sent with a reference. PayMongo calls were written from its public docs and are untested here: try test mode first.
  On XAMPP/Windows, cURL may need a CA bundle: set `curl.cainfo` in php.ini.
- Email: `log` mode saves every email to `roadkey_private/mail.log`. Switch to `smtp` (for example Gmail with an app password) in settings.php when ready.
