-- Run in phpMyAdmin (SQL tab) if you already imported an older database.sql.
USE roadkey;
ALTER TABLE cars MODIFY status ENUM('ok','maint','retired') NOT NULL DEFAULT 'ok';
