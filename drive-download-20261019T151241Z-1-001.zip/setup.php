<?php
// Run once in the browser to create your admin account, then DELETE this file.
require __DIR__ . '/api/config.php';
$msg = ''; $has = true;
try {
  $pdo = db(); $has = (int)$pdo->query('SELECT COUNT(*) FROM admins')->fetchColumn() > 0;
  if (!$has && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = trim($_POST['user'] ?? ''); $p = $_POST['password'] ?? '';
    if (strlen($u) < 3 || strlen($p) < 10) $msg = 'Username needs 3+ characters and password 10+ characters.';
    else { $pdo->prepare('INSERT INTO admins (username,password_hash) VALUES (?,?)')->execute([$u, password_hash($p, PASSWORD_DEFAULT)]); $has = true; $msg = 'Admin created. Now delete setup.php, then sign in at admin/login.html.'; }
  } elseif ($has) $msg = 'An admin already exists. Delete setup.php.';
} catch (PDOException $e) { $msg = 'Cannot reach the database. Start MySQL in XAMPP and import database.sql first.'; }
?><!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Create admin</title><link rel="stylesheet" href="css/style.css">
<div class="login"><div class="l"><h1>First-time setup</h1><p>Your password is stored only as a hash in the database, never in a file.</p></div>
<div class="r"><div style="width:min(360px,100%)"><?php if ($msg) echo '<p class="err">' . htmlspecialchars($msg) . '</p>'; if (!$has): ?>
<form method="post"><h2>Create admin</h2><label>Username<input name="user" required minlength="3"></label><label style="margin-top:10px">Password (10+ characters)<input name="password" type="password" required minlength="10"></label><button style="margin-top:16px">Create admin</button></form><?php endif; ?></div></div></div>
