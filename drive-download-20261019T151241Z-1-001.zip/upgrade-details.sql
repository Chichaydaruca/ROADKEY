-- Run in phpMyAdmin (SQL tab) if you already imported an older database.sql.
-- Afterwards, open Fleet in the admin panel and fill in each car's plate number.
USE roadkey;
ALTER TABLE cars
  ADD COLUMN plate VARCHAR(12) NULL UNIQUE AFTER name,
  ADD COLUMN mileage INT NOT NULL DEFAULT 0 AFTER seats,
  ADD COLUMN photo VARCHAR(60) NULL;
CREATE TABLE IF NOT EXISTS maintenance (
  id INT AUTO_INCREMENT PRIMARY KEY,
  car_id INT NOT NULL,
  kind VARCHAR(30) NOT NULL,
  date_from DATE NOT NULL,
  date_to DATE NOT NULL,
  notes VARCHAR(300) NOT NULL DEFAULT '',
  cost INT NOT NULL DEFAULT 0,
  status ENUM('scheduled','done','cancelled') NOT NULL DEFAULT 'scheduled',
  created_by VARCHAR(50) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (car_id) REFERENCES cars(id),
  INDEX (car_id, date_from, date_to)
);
