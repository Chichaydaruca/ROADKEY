-- Run once in phpMyAdmin (SQL tab) if you already imported an older database.sql.
USE roadkey;
CREATE TABLE IF NOT EXISTS customers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  phone VARCHAR(30) NOT NULL,
  address VARCHAR(200) NULL,
  birth_date DATE NULL,
  license VARCHAR(40) NOT NULL,
  license_expiry DATE NULL,
  emergency_contact VARCHAR(120) NULL,
  notes VARCHAR(500) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX (license)
);
ALTER TABLE bookings
  ADD COLUMN customer_id INT NULL AFTER car_id,
  ADD INDEX (customer_id),
  ADD FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL;
-- Build the customer list from existing bookings (latest details for each email)
INSERT INTO customers (name, email, phone, license, license_expiry)
  SELECT b.name, b.email, b.phone, b.license, b.license_expiry FROM bookings b
  JOIN (SELECT MAX(id) AS id FROM bookings GROUP BY email) x ON x.id = b.id;
UPDATE bookings b JOIN customers c ON c.email = b.email SET b.customer_id = c.id;
